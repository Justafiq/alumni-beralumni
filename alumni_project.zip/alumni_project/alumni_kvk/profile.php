<?php
session_start();
include("../include/connection.php");

// Pastikan login role alumni
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "alumni") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$sql = "SELECT * FROM users WHERE id_user = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("Ralat: Maklumat profil tidak dijumpai.");
}

// Ambil data kerjaya (jika ada)
$sqlKerjaya = "SELECT * FROM kerjaya WHERE id_user = ? ORDER BY id_kerjaya DESC LIMIT 1";
$stmtKerjaya = $conn->prepare($sqlKerjaya);
$stmtKerjaya->bind_param("i", $user_id);
$stmtKerjaya->execute();
$resultKerjaya = $stmtKerjaya->get_result();
$kerjaya = $resultKerjaya->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Alumni</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #e2e8f0; }
    </style>
</head>
<body class="flex justify-center p-4 md:p-8">

    <div class="w-full max-w-4xl space-y-4">

        <!-- Profile Card -->
        <div class="bg-white rounded-lg shadow-md relative">
            <div class="w-full h-32 bg-sky-600 rounded-t-lg"></div>

            <div class="p-6">
                <!-- Gambar -->
                <div class="flex items-end -mt-16 mb-4">
                    <div class="w-28 h-28 md:w-36 md:h-36 rounded-full border-4 border-white shadow-lg overflow-hidden">
                        <img src="<?= !empty($user['gambar']) ? '../uploads/' . htmlspecialchars($user['gambar']) : 'https://placehold.co/300x300/60a5fa/ffffff?text=Alumni' ?>" 
                             alt="Foto Profil" class="w-full h-full object-cover">
                    </div>
                </div>

                <!-- Butang -->
                <div class="absolute top-4 right-4 flex space-x-2">
                    <a href="alumni_dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-900 bg-white rounded-full border border-slate-900 hover:bg-slate-100 transition">
                        <i class="ph-arrow-left-fill text-lg"></i>
                        <span>Kembali</span>
                    </a>
                    <a href="profile_edit.php" class="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-900 bg-white rounded-full border border-slate-900 hover:bg-slate-100 transition">
                        <i class="ph-pencil-fill text-lg"></i>
                        <span>Edit Profil</span>
                    </a>
                </div>

                <!-- Maklumat -->
                <div class="mt-4">
                    <h1 class="text-3xl font-bold text-slate-900"><?= htmlspecialchars($user['nama']) ?></h1>
                    <p class="text-md text-slate-600 mt-1">
                        <?= !empty($kerjaya['jawatan']) ? htmlspecialchars($kerjaya['jawatan']) . " di " . htmlspecialchars($kerjaya['syarikat']) : 'Belum ada kerjaya' ?>
                    </p>
                    <div class="flex items-center space-x-2 text-slate-500 mt-2">
                        <i class="ph-graduation-cap-fill text-lg"></i>
                        <span>Alumni Tahun <?= htmlspecialchars($user['tahun_alumni'] ?? '-') ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bio -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-slate-800 mb-4">Bio</h2>
            <p class="text-slate-600 leading-relaxed">
                <?= !empty($user['bio']) ? nl2br(htmlspecialchars($user['bio'])) : 'Belum ada bio.' ?>
            </p>
        </div>

        <!-- Info -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-slate-800 mb-4">Maklumat Alumni</h2>
            <div class="space-y-3 text-slate-600">
                <div class="flex items-center space-x-3">
                    <i class="ph-envelope-fill text-xl text-sky-500"></i>
                    <span><?= htmlspecialchars($user['emel']) ?></span>
                </div>
                <div class="flex items-center space-x-3">
                    <i class="ph-calendar-blank-fill text-xl text-sky-500"></i>
                    <span><?= htmlspecialchars($user['umur'] ?? '-') ?> Tahun</span>
                </div>
                <div class="flex items-center space-x-3">
                    <i class="ph-map-pin-fill text-xl text-sky-500"></i>
                    <span><?= htmlspecialchars($user['alamat'] ?? 'Alamat tidak tersedia') ?></span>
                </div>
            </div>
        </div>

        <!-- Kerjaya -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-slate-800 mb-4">Kerjaya Semasa</h2>
            <?php if ($kerjaya): ?>
                <div class="space-y-3 text-slate-600">
                    <div class="flex items-center space-x-3">
                        <i class="ph-briefcase-fill text-xl text-sky-500"></i>
                        <span><?= htmlspecialchars($kerjaya['jawatan']) ?> di <?= htmlspecialchars($kerjaya['syarikat']) ?></span>
                    </div>
                    <h2 class="text-xl font-bold text-slate-800 mb-4">Gaji</h2>
                    <?php if (!empty($kerjaya['gaji'])): ?>
                    <div class="flex items-center space-x-3">
                        <i class="ph-currency-circle-dollar-fill text-xl text-sky-500"></i>
                        <span>RM <?= number_format($kerjaya['gaji'], 2) ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p class="text-slate-500">Belum ada maklumat kerjaya.</p>
            <?php endif; ?>
        </div>

    </div>
</body>
</html>
