<?php
session_start();
include("../include/connection.php");

// Pastikan login role alumni
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== "alumni") {
    header("Location: ../login.php");
    exit();
}

$id_user = $_SESSION['user_id'];

// Ambil data user
$sql = "SELECT * FROM users WHERE id_user = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("Ralat: Maklumat profil tidak dijumpai.");
}

// Ambil kerjaya terbaru
$sqlKerjaya = "SELECT * FROM kerjaya WHERE id_user = ? ORDER BY id_kerjaya DESC LIMIT 1";
$stmtK = $conn->prepare($sqlKerjaya);
$stmtK->bind_param("i", $id_user);
$stmtK->execute();
$kerjaya = $stmtK->get_result()->fetch_assoc();

// Simpan perubahan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama         = $_POST['nama'];
    $emel         = $_POST['emel'];
    $umur         = $_POST['umur'];
    $alamat       = $_POST['alamat'];
    $tahun_alumni = $_POST['tahun_alumni'] ?? null;
    $kursus       = $_POST['kursus'] ?? null;
    $bio          = $_POST['bio'];

    // Upload gambar
    $gambar = $user['gambar'];
    if (!empty($_FILES['gambar']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir);
        $fileName = time() . "_" . basename($_FILES['gambar']['name']);
        $targetFile = $targetDir . $fileName;
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetFile)) {
            $gambar = $fileName;
        }
    }

    // Update user (alumni tak boleh tukar role sendiri)
    $update = "UPDATE users 
               SET nama=?, emel=?, umur=?, alamat=?, tahun_alumni=?, kursus=?, bio=?, gambar=? 
               WHERE id_user=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("ssisssssi", $nama, $emel, $umur, $alamat, $tahun_alumni, $kursus, $bio, $gambar, $id_user);
    $stmt->execute();

    // Update kerjaya
    $syarikat   = $_POST['syarikat'] ?? null;
    $pekerjaan  = $_POST['pekerjaan'] ?? null;
    $gaji       = $_POST['gaji'] ?? null;

if ($kerjaya) {
    $updateK = "UPDATE kerjaya 
                SET syarikat=?, jawatan=?, gaji=? 
                WHERE id_kerjaya=?";
    $stmtK = $conn->prepare($updateK);
    $stmtK->bind_param("ssii", $syarikat, $pekerjaan, $gaji, $kerjaya['id_kerjaya']);
    $stmtK->execute();
} else {
    $insertK = "INSERT INTO kerjaya (id_user, syarikat, jawatan, gaji) 
                VALUES (?, ?, ?, ?)";
    $stmtK = $conn->prepare($insertK);
    $stmtK->bind_param("issi", $id_user, $syarikat, $pekerjaan, $gaji);
    $stmtK->execute();

    header("Location: profile.php"); // lepas edit redirect ke profile sendiri
    exit();
}}

?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Edit Profil Alumni</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex justify-center p-6 bg-gray-100">

  <div class="bg-white shadow-md rounded-lg p-6 w-full max-w-2xl">
    <h1 class="text-2xl font-bold mb-4">Edit Profil</h1>
    <form method="POST" enctype="multipart/form-data" class="space-y-4">

      <div>
        <label class="block font-semibold">Nama</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Emel</label>
        <input type="email" name="emel" value="<?= htmlspecialchars($user['emel']) ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Umur</label>
        <input type="number" name="umur" value="<?= htmlspecialchars($user['umur'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Alamat</label>
        <input type="text" name="alamat" value="<?= htmlspecialchars($user['alamat'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Batch Alumni</label>
        <input type="number" name="tahun_alumni" value="<?= htmlspecialchars($user['tahun_alumni'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Kursus</label>
        <input type="text" name="kursus" value="<?= htmlspecialchars($user['kursus'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Kerjaya - Syarikat</label>
        <input type="text" name="syarikat" value="<?= htmlspecialchars($kerjaya['syarikat'] ?? '') ?>" class="w-full border rounded p-2">
      </div>
      <div>
        <label class="block font-semibold">Kerjaya - Jawatan</label>
        <input type="text" name="pekerjaan" value="<?= htmlspecialchars($kerjaya['pekerjaan'] ?? '') ?>" class="w-full border rounded p-2">
      </div>
      <div>
        <label class="block font-semibold">Kerjaya - Gaji (RM)</label>
        <input type="number" step="0.01" name="gaji" value="<?= htmlspecialchars($kerjaya['gaji'] ?? '') ?>" class="w-full border rounded p-2">
      </div>

      <div>
        <label class="block font-semibold">Bio</label>
        <textarea name="bio" rows="4" class="w-full border rounded p-2"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
      </div>

      <div>
        <label class="block font-semibold">Gambar Profil</label>
        <input type="file" name="gambar" class="w-full border rounded p-2">
        <?php if (!empty($user['gambar'])): ?>
          <img src="../uploads/<?= htmlspecialchars($user['gambar']) ?>" class="w-20 h-20 rounded-full mt-2">
        <?php endif; ?>
      </div>

      <div class="flex justify-between mt-6">
        <a href="profile.php" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400">Kembali</a>
        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Simpan</button>
      </div>

    </form>
  </div>

</body>
</html>
