<?php
session_start();
include("../include/connection.php");

// Pastikan user dah login
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== "alumni")) {
    header("Location: ../login.php");
    exit();
}

// Dapatkan search & filter
$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? 'Semua';

// Query database
$sql = "SELECT id_user, nama, kursus, tahun_alumni, role, gambar FROM users WHERE 1";
$params = [];
$types  = "";

// Filter ikut Alumni sahaja
if ($filter === "Alumni") {
    $sql .= " AND role = ?";
    $params[] = "alumni";
    $types   .= "s";
}
elseif ($filter === "Guru") {
    $sql .= " AND role = ?";
    $params[] = "guru";
    $types   .= "s";
}

// Cari ikut nama atau kursus
if (!empty($search)) {
    $sql .= " AND (nama LIKE ? OR kursus LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $types   .= "ss";
}

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Direktori Alumni</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="container mx-auto p-6">

    <!-- Butang Kembali -->
    <div class="mb-4">
        <a href="alumni_dashboard.php" 
           class="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 transition">
            ← Kembali ke Dashboard
        </a>
    </div>

    <h1 class="text-2xl font-bold mb-6">Direktori</h1>

    <!-- Search -->
    <form method="GET" class="flex space-x-2 mb-6">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Cari nama atau kursus..."
               class="flex-1 border px-4 py-2 rounded-lg">
        <select name="filter" class="border px-3 py-2 rounded-lg">
            <option value="Semua" <?= $filter=="Semua"?"selected":"" ?>>Semua</option>
            <option value="Alumni" <?= $filter=="Alumni"?"selected":"" ?>>Alumni</option>
            <option value="Guru" <?= $filter=="Guru"?"selected":"" ?>>Guru</option>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg">Cari</button>
    </form>

    <!-- Profiles -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while($row = $result->fetch_assoc()): ?>
            <div class="bg-white rounded-xl shadow-md p-6 flex flex-col items-center">
                <img src="<?= !empty($row['gambar']) ? '../uploads/'.$row['gambar'] : 'https://placehold.co/100x100' ?>"
                     class="w-24 h-24 rounded-full border-4 border-gray-200">
                <h2 class="text-lg font-semibold mt-4"><?= htmlspecialchars($row['nama']) ?></h2>
                <p class="text-sm text-gray-500"><?= htmlspecialchars($row['kursus'] ?? '-') ?> (<?= htmlspecialchars($row['tahun_alumni'] ?? '-') ?>)</p>
                <a href="profile.php?id=<?= $row['id_user'] ?>" 
                   class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700">Lihat Profil</a>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
