<?php
session_start();
include("../include/connection.php");

// Pastikan login role alumni
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "alumni") {
    header("Location: ../login.php");
    exit();
}

// Logout
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data user (untuk welcome card)
$sql_user = "SELECT * FROM users WHERE id_user = ?";
$stmt = $conn->prepare($sql_user);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_user = $stmt->get_result();
$user = $result_user->fetch_assoc();

// Ambil semua post forum
$sql = "SELECT * FROM forum ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Alumni Dashboard - Feed</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #f9fafb; }
        .sidebar { transition: transform 0.3s ease-in-out; }
        .sidebar-closed { transform: translateX(-100%); }
        .feed-item:hover { transform: translateY(-5px); transition: 0.2s; }
    </style>
</head>
<body class="flex min-h-screen w-full">

    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar w-64 bg-white shadow-xl p-4 flex flex-col sticky top-0 h-screen">
        <h2 class="text-xl font-bold text-gray-700 flex items-center gap-2 mb-6">
            <i class="ph-graduation-cap-fill text-blue-600 text-2xl"></i> Alumni Panel
        </h2>
        <nav class="flex flex-col space-y-3">
            <a href="alumni_dashboard.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-house-fill"></i> Home</a>
            <a href="profile.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-user-circle-fill"></i> Profile</a>
            <a href="announcements.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-megaphone-fill"></i> Pengumuman</a>
            <a href="event.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-calendar-blank-fill"></i> Acara</a>
            <a href="directory.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-users-fill"></i> Direktori Alumni</a>
        <a href="mesej.php" class="flex items-center gap-2 text-gray-600 hover:text-blue-600 font-semibold"><i class="ph-users-fill"></i> Mesej</a>
        </nav>
        <form method="POST" class="mt-auto">
            <button name="logout" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 flex items-center gap-2">
              <i class="ph-sign-out-fill"></i> Logout
          </button>
        </form>
    </aside>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col w-full">
        <!-- Navbar -->
        <header class="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-10">
            <h1 class="text-xl font-bold flex items-center gap-2">
                <i class="ph-graduation-cap-fill text-blue-600 text-2xl"></i> Alumni Dashboard
            </h1>
            <button id="menu-btn" class="md:hidden text-gray-700">
                <i class="ph-list text-3xl"></i>
            </button>
        </header>

        <!-- Welcome Card -->
        <section class="bg-gradient-to-r from-blue-500 to-indigo-500 text-white p-8 rounded-xl shadow-lg mx-6 my-4 flex flex-col md:flex-row items-center justify-between">
            <div>
                <h2 class="text-3xl font-bold mb-1">
                    Selamat Datang, <?= htmlspecialchars($user['nama'] ?? 'Alumni') ?>!
                </h2>
                <p class="text-lg">Terus berhubung dengan komuniti alumni kita.</p>
            </div>
            <div class="w-16 h-16 md:w-20 md:h-20 bg-gray-200 rounded-full overflow-hidden flex items-center justify-center mt-4 md:mt-0">
                <img src="<?= !empty($user['gambar']) ? '../uploads/' . htmlspecialchars($user['gambar']) : 'https://placehold.co/100x100?text=👤' ?>" 
                     alt="Alumni Profile" class="w-full h-full object-cover">
            </div>
        </section>

        <!-- Feed -->
        <main class="p-6 flex-grow">
            <h2 class="text-2xl font-bold text-center mb-6">📸 Feed Komuniti</h2>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if ($result && mysqli_num_rows($result) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <div class="feed-item bg-white rounded-xl shadow-md overflow-hidden transform hover:scale-105 transition-all duration-300">
                            <?php if (!empty($row['gambar'])): ?>
                                <img src="<?= htmlspecialchars($row['gambar']); ?>" class="w-full h-48 object-cover">
                            <?php else: ?>
                                <div class="w-full h-48 bg-gray-200 flex items-center justify-center text-gray-500">
                                    <i class="ph-image text-4xl"></i>
                                </div>
                            <?php endif; ?>
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($row['tajuk']); ?></h3>
                                <p class="text-gray-500 text-sm mb-2"><?= date("d M Y", strtotime($row['created_at'])) ?></p>
                                <p class="text-gray-700 text-sm">
                                    <?= mb_substr(htmlspecialchars($row['kandungan']), 0, 120) ?>...
                                </p>
                                <a href="../include/forum_view.php?id=<?= $row['id_forum'] ?>" 
                                   class="inline-block mt-3 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                   Lihat & Komen
                                </a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="col-span-3 text-center text-gray-500">Belum ada post forum.</p>
                <?php endif; ?>
            </div>
        </main>

        <!-- Footer -->
        <footer class="bg-gray-800 text-white text-center py-3 mt-auto">
            <p>&copy; 2025 Projek Alumni Saya</p>
        </footer>
    </div>

    <script>
        const sidebar = document.getElementById("sidebar");
        const menuBtn = document.getElementById("menu-btn");
        menuBtn?.addEventListener("click", () => {
            sidebar.classList.toggle("sidebar-closed");
        });
    </script>
</body>
</html>
