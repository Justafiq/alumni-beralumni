<?php
session_start();
include("../include/connection.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== "alumni") {
    header("Location: ../login.php");
    exit();
}

$result = $conn->query("SELECT a.*, u.nama FROM announcements a 
                        LEFT JOIN users u ON a.pengirim_id = u.id_user 
                        ORDER BY a.tarikh DESC");
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Pengumuman Alumni</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<!-- Butang -->
                <div class="absolute top-4 right-4 flex space-x-2">
                    <a href="alumni_dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-900 bg-white rounded-full border border-slate-900 hover:bg-slate-100 transition">
                        <i class="ph-arrow-left-fill text-lg"></i>
                        <span>Kembali</span>
                    </a>
                </div>
<body class="bg-gray-100 p-6">
  <h1 class="text-2xl font-bold mb-6">📢 Pengumuman Rasmi</h1>
  <?php while ($row = $result->fetch_assoc()): ?>
    <div class="bg-white rounded-xl shadow p-6 mb-4">
      <h2 class="text-xl font-bold"><?= htmlspecialchars($row['tajuk']) ?></h2>
      <p class="text-gray-600 mt-2"><?= nl2br(htmlspecialchars($row['kandungan'])) ?></p>
      <p class="text-sm text-gray-500">📅 <?= date("d M Y", strtotime($row['tarikh'])) ?></p>
    </div>
  <?php endwhile; ?>
</body>
</html>
