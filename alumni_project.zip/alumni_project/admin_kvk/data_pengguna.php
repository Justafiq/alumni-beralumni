<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya admin boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Padam pengguna
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM users WHERE id_user = $delete_id");
    header("Location: data_pengguna.php");
    exit();
}

// Ambil semua pengguna
$query = "SELECT id_user, nama, tahun_alumni, kursus, pekerjaan, role, sambung_belajar, institusi, emel 
          FROM users ORDER BY id_user DESC";
$result = mysqli_query($conn, $query);

$alumniData = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $alumniData[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin Alumni</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary': '#3B82F6',
                    'primary-dark': '#1D4ED8',
                    'accent': '#10B981',
                    'accent-dark': '#059669'
                }
            }
        }
    }
</script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    body { 
        font-family: 'Inter', sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .glass-effect {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-2px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.3s ease;
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        transform: translateY(-1px);
    }
    
    .table-row-hover {
        transition: all 0.2s ease;
    }
    
    .table-row-hover:hover {
        background: linear-gradient(90deg, #f8fafc 0%, #e2e8f0 100%);
        transform: scale(1.01);
    }
    
    .loading-spinner {
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .fade-in {
        animation: fadeIn 0.5s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .status-badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .status-alumni {
        background-color: #dbeafe;
        color: #1e40af;
    }
    
    .status-guru {
        background-color: #d1fae5;
        color: #065f46;
    }
    
    .status-admin {
        background-color: #fef3c7;
        color: #92400e;
    }
</style>
</head>
<body class="min-h-screen p-4 sm:p-6">

<div class="max-w-7xl mx-auto">
    
    <!-- Header Section -->
    <div class="glass-effect rounded-2xl shadow-2xl p-6 sm:p-8 mb-8 fade-in">
        <div class="flex flex-col lg:flex-row justify-between items-center">
            <div class="flex items-center space-x-6 mb-6 lg:mb-0">
                <div class="relative">
                    <div class="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i class="fas fa-graduation-cap text-white text-3xl"></i>
                    </div>
                    <div class="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-white"></div>
                </div>
                <div>
                    <h1 class="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        Dashboard Admin
                    </h1>
                    <p class="text-lg text-gray-600 mt-1 flex items-center">
                        <i class="fas fa-users mr-2 text-blue-500"></i>
                        Pengurusan Data Alumni
                    </p>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-3">
                <a href="admin_dashboard.php" class="px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-arrow-left"></i>
                    <span>Kembali ke Dashboard</span>
                </a>
                <button id="export-btn" class="px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-download"></i>
                    <span>Export Data</span>
                </button>
                <a href="tambah_user.php" class="px-6 py-3 btn-gradient text-white rounded-xl font-semibold shadow-lg hover:shadow-xl flex items-center space-x-2">
                    <i class="fas fa-plus"></i>
                    <span>Tambah Pengguna</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="glass-effect rounded-2xl p-6 card-hover fade-in">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-medium">Total Pengguna</p>
                    <p id="total-users" class="text-3xl font-bold text-blue-600">0</p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-users text-blue-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="glass-effect rounded-2xl p-6 card-hover fade-in">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-medium">Alumni</p>
                    <p id="total-alumni-count" class="text-3xl font-bold text-green-600">0</p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-graduation-cap text-green-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="glass-effect rounded-2xl p-6 card-hover fade-in">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-medium">Guru</p>
                    <p id="total-guru-count" class="text-3xl font-bold text-purple-600">0</p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-chalkboard-teacher text-purple-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="glass-effect rounded-2xl p-6 card-hover fade-in">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-medium">Admin</p>
                    <p id="total-admin-count" class="text-3xl font-bold text-orange-600">0</p>
                </div>
                <div class="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                    <i class="fas fa-user-shield text-orange-600 text-xl"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters Section -->
    <div class="glass-effect rounded-2xl shadow-xl p-6 mb-8 fade-in">
        <div class="flex items-center mb-4">
            <i class="fas fa-filter text-blue-600 text-xl mr-3"></i>
            <h2 class="text-xl font-semibold text-gray-800">Filter & Carian</h2>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-search mr-1"></i>
                    Cari Pengguna
                </label>
                <input type="text" id="search-filter" 
                       placeholder="Nama, kursus, pekerjaan..." 
                       class="w-full p-3 pl-10 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                <i class="fas fa-search absolute left-3 top-11 text-gray-400"></i>
            </div>
            
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-user-tag mr-1"></i>
                    Peranan
                </label>
                <select id="role-filter" class="w-full p-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                    <option value="all">Semua Peranan</option>
                    <option value="alumni">Alumni</option>
                    <option value="guru">Guru</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            
            <div class="relative">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    <i class="fas fa-calendar mr-1"></i>
                    Tahun Alumni
                </label>
                <select id="batch-filter" class="w-full p-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                    <option value="all">Semua Tahun</option>
                </select>
            </div>
            
            <div class="flex flex-col justify-end">
                <button id="filter-btn" class="w-full py-3 btn-gradient text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center space-x-2">
                    <i class="fas fa-filter"></i>
                    <span>Tapis Data</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Results Section -->
    <div class="glass-effect rounded-2xl shadow-xl p-6 fade-in">
        <div class="flex flex-col sm:flex-row justify-between items-center mb-6">
            <div class="flex items-center mb-4 sm:mb-0">
                <i class="fas fa-table text-blue-600 text-xl mr-3"></i>
                <h2 class="text-xl font-semibold text-gray-800">Senarai Pengguna</h2>
            </div>
            <div class="flex items-center space-x-4">
                <p id="total-alumni" class="text-lg font-semibold text-gray-600 flex items-center">
                    <i class="fas fa-info-circle mr-2 text-blue-500"></i>
                    <span>Jumlah: 0</span>
                </p>
            </div>
        </div>

        <!-- Loading State -->
        <div id="loading" class="hidden flex justify-center items-center py-12">
            <div class="loading-spinner w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full"></div>
            <span class="ml-3 text-gray-600">Memuat data...</span>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto rounded-xl border border-gray-200 shadow-sm">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gradient-to-r from-blue-600 to-purple-600">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-user mr-2"></i>Nama
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Tahun
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-book mr-2"></i>Kursus
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-briefcase mr-2"></i>Pekerjaan
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-user-tag mr-2"></i>Peranan
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-school mr-2"></i>Sambung Belajar
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-university mr-2"></i>Institusi
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-envelope mr-2"></i>Email
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-cogs mr-2"></i>Aksi
                        </th>
                    </tr>
                </thead>
                <tbody id="alumni-table-body" class="bg-white divide-y divide-gray-200"></tbody>
            </table>
        </div>

        <!-- Empty State -->
        <div id="empty-state" class="hidden text-center py-12">
            <i class="fas fa-search text-gray-300 text-6xl mb-4"></i>
            <h3 class="text-xl font-semibold text-gray-600 mb-2">Tiada Data Ditemui</h3>
            <p class="text-gray-500">Cuba ubah kriteria carian anda atau tambah pengguna baru.</p>
        </div>
    </div>

</div>

<script>
const alumniData = <?php echo json_encode($alumniData); ?>;
const tableBody = document.getElementById('alumni-table-body');
const batchFilter = document.getElementById('batch-filter');
const roleFilter = document.getElementById('role-filter');
const searchFilter = document.getElementById('search-filter');
const filterBtn = document.getElementById('filter-btn');
const totalAlumniElement = document.getElementById('total-alumni');
const emptyState = document.getElementById('empty-state');
const loadingState = document.getElementById('loading');

// Stats elements
const totalUsersEl = document.getElementById('total-users');
const totalAlumniCountEl = document.getElementById('total-alumni-count');
const totalGuruCountEl = document.getElementById('total-guru-count');
const totalAdminCountEl = document.getElementById('total-admin-count');

// Update stats
const updateStats = (data) => {
    const totalUsers = data.length;
    const alumniCount = data.filter(u => u.role === 'alumni').length;
    const guruCount = data.filter(u => u.role === 'guru').length;
    const adminCount = data.filter(u => u.role === 'admin').length;
    
    // Animate numbers
    animateNumber(totalUsersEl, totalUsers);
    animateNumber(totalAlumniCountEl, alumniCount);
    animateNumber(totalGuruCountEl, guruCount);
    animateNumber(totalAdminCountEl, adminCount);
};

// Animate number counting
const animateNumber = (element, target) => {
    const start = 0;
    const duration = 1000;
    const startTime = performance.now();
    
    const updateNumber = (currentTime) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const current = Math.floor(progress * target);
        
        element.textContent = current;
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        }
    };
    
    requestAnimationFrame(updateNumber);
};

const populateFilters = (data) => {
    const years = [...new Set(data.map(a => a.tahun_alumni).filter(year => year))].sort();
    batchFilter.innerHTML = '<option value="all">Semua Tahun</option>';
    years.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        batchFilter.appendChild(option);
    });
};

const getRoleStatusClass = (role) => {
    switch(role) {
        case 'alumni': return 'status-badge status-alumni';
        case 'guru': return 'status-badge status-guru';
        case 'admin': return 'status-badge status-admin';
        default: return 'status-badge status-alumni';
    }
};

const getRoleIcon = (role) => {
    switch(role) {
        case 'alumni': return 'fas fa-graduation-cap';
        case 'guru': return 'fas fa-chalkboard-teacher';
        case 'admin': return 'fas fa-user-shield';
        default: return 'fas fa-user';
    }
};

const renderTable = (data) => {
    // Show loading
    loadingState.classList.remove('hidden');
    tableBody.innerHTML = '';
    emptyState.classList.add('hidden');
    
    setTimeout(() => {
        loadingState.classList.add('hidden');
        totalAlumniElement.innerHTML = `<i class="fas fa-info-circle mr-2 text-blue-500"></i><span>Jumlah: ${data.length}</span>`;
        
        if (data.length === 0) {
            emptyState.classList.remove('hidden');
            return;
        }
        
        data.forEach((item, index) => {
            const row = document.createElement('tr');
            row.className = 'table-row-hover';
            row.style.animationDelay = `${index * 0.05}s`;
            
            const roleClass = getRoleStatusClass(item.role);
            const roleIcon = getRoleIcon(item.role);
            
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm mr-3">
                            ${item.nama.charAt(0).toUpperCase()}
                        </div>
                        <div>
                            <div class="text-sm font-semibold text-gray-900">${item.nama}</div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    <span class="bg-gray-100 px-2 py-1 rounded-lg">${item.tahun_alumni || '-'}</span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.kursus || '-'}">
                    ${item.kursus || '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.pekerjaan || '-'}">
                    ${item.pekerjaan || '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="${roleClass}">
                        <i class="${roleIcon} mr-1"></i>
                        ${item.role.charAt(0).toUpperCase() + item.role.slice(1)}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-600">
                    ${item.sambung_belajar ? '<span class="text-green-600"><i class="fas fa-check mr-1"></i>Ya</span>' : '<span class="text-gray-400"><i class="fas fa-times mr-1"></i>Tidak</span>'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.institusi || '-'}">
                    ${item.institusi || '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.emel || '-'}">
                    ${item.emel || '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <div class="flex space-x-2">
                        <a href="edit_user.php?id=${item.id_user}" 
                           class="px-3 py-1 bg-yellow-500 hover:bg-yellow-600 text-white rounded-lg font-semibold shadow-sm hover:shadow-md transition-all duration-200 flex items-center space-x-1">
                            <i class="fas fa-edit text-xs"></i>
                            <span>Edit</span>
                        </a>
                        <a href="?delete_id=${item.id_user}" 
                           onclick="return confirm('Padam pengguna ini?')" 
                           class="px-3 py-1 bg-red-500 hover:bg-red-600 text-white rounded-lg font-semibold shadow-sm hover:shadow-md transition-all duration-200 flex items-center space-x-1">
                            <i class="fas fa-trash text-xs"></i>
                            <span>Padam</span>
                        </a>
                    </div>
                </td>
            `;
            
            row.classList.add('fade-in');
            tableBody.appendChild(row);
        });
    }, 300);
};

const filterAndRenderTable = () => {
    let filtered = alumniData;
    const year = batchFilter.value;
    const role = roleFilter.value;
    const query = searchFilter.value.toLowerCase();

    if (year !== 'all') {
        filtered = filtered.filter(a => a.tahun_alumni && a.tahun_alumni.toString() === year);
    }
    if (role !== 'all') {
        filtered = filtered.filter(a => a.role === role);
    }
    if (query) {
        filtered = filtered.filter(a =>
            (a.nama && a.nama.toLowerCase().includes(query)) ||
            (a.kursus && a.kursus.toLowerCase().includes(query)) ||
            (a.pekerjaan && a.pekerjaan.toLowerCase().includes(query)) ||
            (a.institusi && a.institusi.toLowerCase().includes(query)) ||
            (a.emel && a.emel.toLowerCase().includes(query))
        );
    }

    renderTable(filtered);
};

// Export functionality
document.getElementById('export-btn').addEventListener('click', () => {
    const csv = convertToCSV(alumniData);
    downloadCSV(csv, 'data_alumni.csv');
});

const convertToCSV = (data) => {
    const headers = ['Nama', 'Tahun Alumni', 'Kursus', 'Pekerjaan', 'Peranan', 'Sambung Belajar', 'Institusi', 'Email'];
    const csvContent = [
        headers.join(','),
        ...data.map(row => [
            `"${row.nama || ''}"`,
            `"${row.tahun_alumni || ''}"`,
            `"${row.kursus || ''}"`,
            `"${row.pekerjaan || ''}"`,
            `"${row.role || ''}"`,
            `"${row.sambung_belajar || ''}"`,
            `"${row.institusi || ''}"`,
            `"${row.emel || ''}"`
        ].join(','))
    ].join('\n');
    
    return csvContent;
};

const downloadCSV = (csv, filename) => {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// Event listeners
filterBtn.addEventListener('click', filterAndRenderTable);
searchFilter.addEventListener('keyup', (e) => {
    if (e.key === 'Enter') {
        filterAndRenderTable();
    }
});

// Real-time search (with debounce)
let searchTimeout;
searchFilter.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(filterAndRenderTable, 300);
});

// Initialize
populateFilters(alumniData);
updateStats(alumniData);
filterAndRenderTable();

// Add some entrance animations
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.fade-in');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });
});
</script>
</body>
</html>