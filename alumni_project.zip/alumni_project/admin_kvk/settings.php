<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya admin boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil info admin
$query = "SELECT id_user, nama, emel, katalaluan FROM users WHERE id_user=?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$admin = mysqli_fetch_assoc($result);

// Handle update profile
if (isset($_POST['update_profile'])) {
    $nama = $_POST['nama'];
    $emel = $_POST['emel'];

    $updateQuery = "UPDATE users SET nama=?, emel=? WHERE id_user=?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "ssi", $nama, $emel, $user_id);
    if (mysqli_stmt_execute($stmt)) {
        $successMsg = "Profil berjaya dikemaskini.";
        $_SESSION['nama'] = $nama; // update session
        $admin['nama'] = $nama;
        $admin['emel'] = $emel;
    } else {
        $errorMsg = "Profil gagal dikemaskini.";
    }
}

// Handle change password
if (isset($_POST['change_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    if ($new_pass !== $confirm_pass) {
        $errorMsg = "Katalaluan baru dan pengesahan tidak sama.";
    } elseif ($current_pass !== $admin['katalaluan']) { // banding terus dengan value di DB
        $errorMsg = "Katalaluan lama salah.";
    } else {
        $updatePass = "UPDATE users SET katalaluan=? WHERE id_user=?";
        $stmt = mysqli_prepare($conn, $updatePass);
        mysqli_stmt_bind_param($stmt, "si", $new_pass, $user_id);
        if (mysqli_stmt_execute($stmt)) {
            $successMsg = "Katalaluan berjaya dikemaskini.";
            $admin['katalaluan'] = $new_pass;
        } else {
            $errorMsg = "Gagal mengemaskini katalaluan.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tetapan Admin - Alumni System</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary': '#3B82F6',
                    'primary-dark': '#1D4ED8',
                    'accent': '#10B981',
                    'accent-dark': '#059669'
                }
            }
        }
    }
</script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    body { 
        font-family: 'Inter', sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .glass-effect {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 32px 64px -12px rgba(0, 0, 0, 0.35);
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px 0 rgba(102, 126, 234, 0.4);
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        transform: translateY(-2px);
        box-shadow: 0 8px 25px 0 rgba(102, 126, 234, 0.6);
    }
    
    .btn-green {
        background: linear-gradient(135deg, #10B981 0%, #059669 100%);
        box-shadow: 0 4px 15px 0 rgba(16, 185, 129, 0.4);
    }
    
    .btn-green:hover {
        background: linear-gradient(135deg, #059669 0%, #047857 100%);
        transform: translateY(-2px);
        box-shadow: 0 8px 25px 0 rgba(16, 185, 129, 0.6);
    }
    
    .input-focus {
        transition: all 0.3s ease;
        border: 2px solid #e5e7eb;
    }
    
    .input-focus:focus {
        outline: none;
        border-color: #3B82F6;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        transform: scale(1.02);
    }
    
    .fade-in {
        animation: fadeIn 0.8s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .alert-success {
        background: linear-gradient(135deg, #D1FAE5 0%, #A7F3D0 100%);
        border: 1px solid #10B981;
        color: #065F46;
    }
    
    .alert-error {
        background: linear-gradient(135deg, #FEE2E2 0%, #FECACA 100%);
        border: 1px solid #EF4444;
        color: #991B1B;
    }
    
    .profile-avatar {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .settings-nav {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.8) 100%);
        backdrop-filter: blur(10px);
    }
    
    .password-strength {
        height: 4px;
        border-radius: 2px;
        transition: all 0.3s ease;
    }
    
    .strength-weak { background: #EF4444; width: 25%; }
    .strength-medium { background: #F59E0B; width: 50%; }
    .strength-strong { background: #10B981; width: 75%; }
    .strength-very-strong { background: #059669; width: 100%; }
</style>
</head>
<body class="min-h-screen p-4 sm:p-6">

<div class="max-w-6xl mx-auto">
    
    <!-- Enhanced Header -->
    <div class="glass-effect rounded-2xl shadow-2xl p-6 sm:p-8 mb-8 fade-in">
        <div class="flex flex-col lg:flex-row items-center justify-between">
            <div class="flex items-center space-x-6 mb-6 lg:mb-0">
                <div class="relative">
                    <div class="w-20 h-20 profile-avatar rounded-2xl flex items-center justify-center shadow-lg">
                        <i class="fas fa-user-cog text-white text-3xl"></i>
                    </div>
                    <div class="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-white flex items-center justify-center">
                        <i class="fas fa-check text-white text-xs"></i>
                    </div>
                </div>
                <div>
                    <h1 class="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                        Tetapan Admin
                    </h1>
                    <p class="text-lg text-gray-600 mt-1 flex items-center">
                        <i class="fas fa-cog mr-2 text-purple-500"></i>
                        Kelola profil dan keselamatan akaun anda
                    </p>
                </div>
            </div>
            
            <div class="flex gap-3">
                <a href="admin_dashboard.php" class="px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-arrow-left"></i>
                    <span>Kembali</span>
                </a>
                <button onclick="window.print()" class="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-print"></i>
                    <span>Cetak</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Admin Info Card -->
    <div class="glass-effect rounded-2xl shadow-xl p-8 mb-8 card-hover fade-in" style="animation-delay: 0.2s">
        <div class="text-center">
            <div class="w-24 h-24 profile-avatar rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <span class="text-3xl font-bold text-white">
                    <?= strtoupper(substr($admin['nama'], 0, 2)) ?>
                </span>
            </div>
            <h2 class="text-2xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($admin['nama']) ?></h2>
            <p class="text-gray-600 mb-4 flex items-center justify-center">
                <i class="fas fa-envelope mr-2 text-blue-500"></i>
                <?= htmlspecialchars($admin['emel']) ?>
            </p>
            <div class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
                <i class="fas fa-shield-alt mr-2 text-purple-600"></i>
                <span class="font-semibold text-purple-800">Administrator</span>
            </div>
        </div>
    </div>

    <!-- Alert Messages -->
    <?php if(isset($successMsg)): ?>
        <div class="alert-success p-4 rounded-xl mb-6 flex items-center fade-in" style="animation-delay: 0.3s">
            <div class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-4">
                <i class="fas fa-check text-white"></i>
            </div>
            <div>
                <h4 class="font-semibold mb-1">Berjaya!</h4>
                <p><?= $successMsg ?></p>
            </div>
        </div>
    <?php endif; ?>

    <?php if(isset($errorMsg)): ?>
        <div class="alert-error p-4 rounded-xl mb-6 flex items-center fade-in" style="animation-delay: 0.3s">
            <div class="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center mr-4">
                <i class="fas fa-exclamation-triangle text-white"></i>
            </div>
            <div>
                <h4 class="font-semibold mb-1">Ralat!</h4>
                <p><?= $errorMsg ?></p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        <!-- Profile Update Form -->
        <div class="glass-effect rounded-2xl shadow-xl p-8 card-hover fade-in" style="animation-delay: 0.4s">
            <div class="flex items-center mb-6">
                <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mr-4">
                    <i class="fas fa-user-edit text-white text-xl"></i>
                </div>
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">Kemaskini Profil</h2>
                    <p class="text-gray-600 text-sm">Ubah maklumat peribadi anda</p>
                </div>
            </div>
            
            <form method="POST" id="profileForm" class="space-y-6">
                <div class="relative">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-user mr-2 text-blue-500"></i>
                        Nama Penuh
                    </label>
                    <input type="text" name="nama" value="<?= htmlspecialchars($admin['nama']) ?>" 
                           class="w-full p-4 input-focus rounded-xl shadow-sm" 
                           placeholder="Masukkan nama penuh anda" required>
                </div>
                
                <div class="relative">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-envelope mr-2 text-blue-500"></i>
                        Alamat Emel
                    </label>
                    <input type="email" name="emel" value="<?= htmlspecialchars($admin['emel']) ?>" 
                           class="w-full p-4 input-focus rounded-xl shadow-sm" 
                           placeholder="contoh@emel.com" required>
                </div>
                
                <div class="flex items-center justify-between pt-4">
                    <div class="flex items-center text-sm text-gray-500">
                        <i class="fas fa-info-circle mr-2"></i>
                        Maklumat akan dikemaskini selepas disimpan
                    </div>
                    <button type="submit" name="update_profile" 
                            class="px-8 py-3 btn-gradient text-white rounded-xl font-semibold flex items-center space-x-2 hover:shadow-xl transition-all duration-300">
                        <i class="fas fa-save"></i>
                        <span>Simpan Profil</span>
                    </button>
                </div>
            </form>
        </div>

        <!-- Password Change Form -->
        <div class="glass-effect rounded-2xl shadow-xl p-8 card-hover fade-in" style="animation-delay: 0.5s">
            <div class="flex items-center mb-6">
                <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mr-4">
                    <i class="fas fa-lock text-white text-xl"></i>
                </div>
                <div>
                    <h2 class="text-2xl font-bold text-gray-800">Tukar Katalaluan</h2>
                    <p class="text-gray-600 text-sm">Pastikan keselamatan akaun anda</p>
                </div>
            </div>
            
            <form method="POST" id="passwordForm" class="space-y-6">
                <div class="relative">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-key mr-2 text-green-500"></i>
                        Katalaluan Lama
                    </label>
                    <div class="relative">
                        <input type="password" name="current_password" id="currentPassword"
                               class="w-full p-4 pr-12 input-focus rounded-xl shadow-sm" 
                               placeholder="Masukkan katalaluan lama" required>
                        <button type="button" onclick="togglePassword('currentPassword', this)" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="relative">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-lock mr-2 text-green-500"></i>
                        Katalaluan Baru
                    </label>
                    <div class="relative">
                        <input type="password" name="new_password" id="newPassword"
                               class="w-full p-4 pr-12 input-focus rounded-xl shadow-sm" 
                               placeholder="Masukkan katalaluan baru" required
                               onkeyup="checkPasswordStrength(this.value)">
                        <button type="button" onclick="togglePassword('newPassword', this)" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <!-- Password Strength Indicator -->
                    <div class="mt-2">
                        <div class="flex justify-between items-center mb-1">
                            <span class="text-xs text-gray-500">Kekuatan Katalaluan:</span>
                            <span id="strengthText" class="text-xs font-semibold"></span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-1">
                            <div id="strengthBar" class="password-strength rounded-full"></div>
                        </div>
                    </div>
                </div>
                
                <div class="relative">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        <i class="fas fa-check-circle mr-2 text-green-500"></i>
                        Pengesahan Katalaluan
                    </label>
                    <div class="relative">
                        <input type="password" name="confirm_password" id="confirmPassword"
                               class="w-full p-4 pr-12 input-focus rounded-xl shadow-sm" 
                               placeholder="Ulang katalaluan baru" required
                               onkeyup="checkPasswordMatch()">
                        <button type="button" onclick="togglePassword('confirmPassword', this)" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                            <i class="fas fa-eye"></i>
                        </button>
                        <div id="matchIndicator" class="absolute right-12 top-1/2 transform -translate-y-1/2"></div>
                    </div>
                </div>
                
                <div class="flex items-center justify-between pt-4">
                    <div class="flex items-center text-sm text-gray-500">
                        <i class="fas fa-shield-alt mr-2"></i>
                        Gunakan katalaluan yang kuat
                    </div>
                    <button type="submit" name="change_password" 
                            class="px-8 py-3 btn-green text-white rounded-xl font-semibold flex items-center space-x-2 hover:shadow-xl transition-all duration-300">
                        <i class="fas fa-lock"></i>
                        <span>Kemaskini</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Security Tips -->
    <div class="glass-effect rounded-2xl shadow-xl p-8 mt-8 fade-in" style="animation-delay: 0.6s">
        <div class="text-center mb-6">
            <div class="w-16 h-16 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-lightbulb text-white text-2xl"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-800 mb-2">Tips Keselamatan</h3>
            <p class="text-gray-600">Ikuti panduan berikut untuk keselamatan akaun yang optimum</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200">
                <i class="fas fa-key text-blue-600 text-2xl mb-3"></i>
                <h4 class="font-semibold text-blue-800 mb-2">Katalaluan Kuat</h4>
                <p class="text-sm text-blue-600">Gunakan kombinasi huruf, nombor dan simbol</p>
            </div>
            
            <div class="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200">
                <i class="fas fa-sync-alt text-green-600 text-2xl mb-3"></i>
                <h4 class="font-semibold text-green-800 mb-2">Kemaskini Berkala</h4>
                <p class="text-sm text-green-600">Tukar katalaluan setiap 3-6 bulan</p>
            </div>
            
            <div class="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-xl border border-red-200">
                <i class="fas fa-user-shield text-red-600 text-2xl mb-3"></i>
                <h4 class="font-semibold text-red-800 mb-2">Jangan Kongsi</h4>
                <p class="text-sm text-red-600">Pastikan maklumat login hanya anda yang tahu</p>
            </div>
        </div>
    </div>

</div>

<script>
// Toggle password visibility
function togglePassword(fieldId, button) {
    const field = document.getElementById(fieldId);
    const icon = button.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Check password strength
function checkPasswordStrength(password) {
    const strengthBar = document.getElementById('strengthBar');
    const strengthText = document.getElementById('strengthText');
    
    let strength = 0;
    let text = '';
    let className = '';
    
    // Check password criteria (lebih mudah untuk mencapai 100%)
    if (password.length >= 6) strength += 1;  // Kurangkan dari 8 ke 6
    if (password.match(/[a-z]/)) strength += 1;  // Huruf kecil
    if (password.match(/[A-Z]/)) strength += 1;  // Huruf besar
    if (password.match(/[0-9]/)) strength += 1;  // Nombor
    
    // Set strength level (4 kriteria sahaja, lebih mudah capai 100%)
    switch (strength) {
        case 0:
            text = 'Sangat Lemah';
            className = 'strength-weak';
            break;
        case 1:
            text = 'Lemah';
            className = 'strength-weak';
            break;
        case 2:
            text = 'Sederhana';
            className = 'strength-medium';
            break;
        case 3:
            text = 'Kuat';
            className = 'strength-strong';
            break;
        case 4:
            text = 'Sangat Kuat';
            className = 'strength-very-strong';
            break;
    }
    
    strengthText.textContent = text;
    strengthBar.className = `password-strength ${className}`;
}

// Check password match
function checkPasswordMatch() {
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const indicator = document.getElementById('matchIndicator');
    
    if (confirmPassword.length > 0) {
        if (newPassword === confirmPassword) {
            indicator.innerHTML = '<i class="fas fa-check text-green-500"></i>';
        } else {
            indicator.innerHTML = '<i class="fas fa-times text-red-500"></i>';
        }
    } else {
        indicator.innerHTML = '';
    }
}

// Form animations and validation
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth focus animations to inputs
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-success, .alert-error');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'all 0.5s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            setTimeout(() => {
                alert.remove();
            }, 500);
        }, 5000);
    });
});

// Print functionality
window.addEventListener('beforeprint', function() {
    document.body.style.background = 'white';
    const glassElements = document.querySelectorAll('.glass-effect');
    glassElements.forEach(el => {
        el.style.background = 'white';
        el.style.border = '1px solid #e5e7eb';
        el.style.boxShadow = 'none';
    });
});

window.addEventListener('afterprint', function() {
    location.reload(); // Reload to restore original styles
});
</script>

<!-- Print Styles -->
<style media="print">
    @page {
        margin: 1cm;
        size: A4;
    }
    
    body {
        background: white !important;
        -webkit-print-color-adjust: exact;
    }
    
    .glass-effect {
        background: white !important;
        border: 1px solid #e5e7eb !important;
        box-shadow: none !important;
    }
    
    .btn-gradient, .btn-green, .profile-avatar {
        background: #3B82F6 !important;
        color: white !important;
    }
    
    .fade-in {
        animation: none !important;
    }
    
    .card-hover:hover {
        transform: none !important;
    }
    
    /* Hide interactive elements when printing */
    button[type="button"], .password-strength {
        display: none !important;
    }
</style>

</body>
</html>
