<?php
session_start();
include("../include/connection.php");

// ✅ Hanya admin boleh masuk
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

$success_message = '';
$error_message = '';

// ✅ Tambah / Edit Pengumuman
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit'])) {
    $id_edit = $_POST['id_edit'] ?? null;
    $tajuk = trim($_POST['tajuk']);
    $kandungan = trim($_POST['kandungan']);
    $kategori = $_POST['kategori'];
    $tarikh_tamat = !empty($_POST['tarikh_tamat']) ? $_POST['tarikh_tamat'] : NULL;

    $pengirim_id = $_SESSION['user_id']; // ikut login session
    $pengirim_role = $_SESSION['role'];

    if (empty($tajuk) || empty($kandungan)) {
        $error_message = "❌ Tajuk dan kandungan wajib diisi!";
    } else {
        $gambar_path = $_POST['old_gambar'] ?? NULL;

        // ✅ Upload gambar
        if (!empty($_FILES['gambar']['name'])) {
            $upload_dir = "../uploads/announcements/";
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

            $file_ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
            $file_name = time() . "_" . uniqid() . "." . $file_ext;
            $target_file = $upload_dir . $file_name;

            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                $gambar_path = $file_name;
            }
        }

        // ✅ Insert or Update
        if ($id_edit) {
            $stmt = $conn->prepare("UPDATE announcements 
                SET tajuk=?, kandungan=?, kategori=?, tarikh_tamat=?, gambar=? 
                WHERE id_announcement=?");
            $stmt->bind_param("sssssi", $tajuk, $kandungan, $kategori, $tarikh_tamat, $gambar_path, $id_edit);
            if ($stmt->execute()) {
                $success_message = "✅ Pengumuman berjaya dikemaskini!";
            } else {
                $error_message = "❌ SQL Error (Update): " . $stmt->error;
            }
        } else {
            $stmt = $conn->prepare("INSERT INTO announcements 
                (tajuk, kandungan, pengirim_id, pengirim_role, tarikh_tamat, gambar, kategori) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssissss", $tajuk, $kandungan, $pengirim_id, $pengirim_role, $tarikh_tamat, $gambar_path, $kategori);
            if ($stmt->execute()) {
                $success_message = "✅ Pengumuman berjaya diterbitkan!";
            } else {
                $error_message = "❌ SQL Error (Insert): " . $stmt->error;
            }
        }
    }
}

// ✅ Delete
if (isset($_GET['delete'])) {
    $id_delete = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM announcements WHERE id_announcement=?");
    $stmt->bind_param("i", $id_delete);
    if ($stmt->execute()) {
        $success_message = "✅ Pengumuman berjaya dipadam!";
    } else {
        $error_message = "❌ SQL Error (Delete): " . $stmt->error;
    }
}

// ✅ Ambil semua pengumuman
$result = $conn->query("SELECT * FROM announcements ORDER BY tarikh DESC");
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Pengumuman</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
</head>
<body class="bg-gray-100 p-6">

<h1 class="text-3xl font-bold mb-4">📢 Pengumuman Admin</h1>
<a href="admin_dashboard.php" class="bg-green-600 text-white px-4 py-2 rounded mb-6 inline-block hover:bg-green-700">⬅ Dashboard</a>

<?php if ($success_message): ?>
<div class="bg-green-100 text-green-800 p-4 rounded mb-4"><?= $success_message ?></div>
<?php endif; ?>
<?php if ($error_message): ?>
<div class="bg-red-100 text-red-800 p-4 rounded mb-4"><?= $error_message ?></div>
<?php endif; ?>

<!-- Button tambah -->
<button onclick="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-4">+ Tambah Pengumuman</button>

<!-- Modal Form -->
<div id="modal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center">
    <div class="bg-white p-6 rounded shadow w-full max-w-xl">
        <h2 class="text-xl font-bold mb-4">✍ Cipta / Kemaskini Pengumuman</h2>
        <form id="modalForm" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id_edit" id="id_edit">
            <input type="hidden" name="old_gambar" id="old_gambar">

            <input type="text" name="tajuk" id="tajuk" placeholder="Tajuk" class="w-full border px-3 py-2 rounded mb-2" required>
            <select name="kategori" id="kategori" class="w-full border px-3 py-2 rounded mb-2">
                <option value="Akademik">Akademik</option>
                <option value="Event">Event</option>
                <option value="Aktiviti">Aktiviti</option>
                <option value="Lain-lain">Lain-lain</option>
            </select>

            <!-- Tarikh tamat optional -->
            <input type="datetime-local" name="tarikh_tamat" id="tarikh_tamat" class="w-full border px-3 py-2 rounded mb-2">

            <input type="file" name="gambar" id="gambar" class="w-full border px-3 py-2 rounded mb-2">
            <textarea name="kandungan" id="editor" class="w-full border px-3 py-2 rounded mb-2" placeholder="Isi kandungan..." required></textarea>

            <div class="flex justify-end gap-2">
                <button type="button" onclick="closeModal()" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Batal</button>
                <button type="submit" name="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- Senarai pengumuman -->
<div class="space-y-4">
<?php if ($result && $result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="bg-white p-4 rounded shadow flex flex-col md:flex-row justify-between">
            <div class="flex-1">
                <h3 class="font-bold text-lg"><?= htmlspecialchars($row['tajuk']) ?></h3>
                <p class="text-gray-600"><?= substr(strip_tags($row['kandungan']), 0, 200) ?></p>
                <p class="text-sm text-gray-500 mt-1">Kategori: <?= $row['kategori'] ?> | Tarikh: <?= date('d/m/Y H:i', strtotime($row['tarikh'])) ?></p>
            </div>
            <div class="flex gap-2 mt-4 md:mt-0">
                <button onclick="editAnnouncement(<?= $row['id_announcement'] ?>,'<?= addslashes($row['tajuk']) ?>','<?= addslashes($row['kandungan']) ?>','<?= $row['kategori'] ?>','<?= $row['tarikh_tamat'] ?>','<?= $row['gambar'] ?>')" class="bg-yellow-500 text-white px-3 py-1 rounded">Edit</button>
                <a href="?delete=<?= $row['id_announcement'] ?>" onclick="return confirm('Padam pengumuman ini?');" class="bg-red-500 text-white px-3 py-1 rounded">Padam</a>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <div class="text-center text-gray-500 p-8">Tiada pengumuman</div>
<?php endif; ?>
</div>

<script>
let editor;

// Buka modal
function openModal(){
    document.getElementById('modal').classList.remove('hidden');
    if(!editor){
        ClassicEditor.create(document.querySelector('#editor')).then(ed=>{ editor = ed; });
    }
}

// Tutup modal
function closeModal(){
    document.getElementById('modal').classList.add('hidden');
    document.getElementById('modalForm').reset();
    if(editor) editor.setData('');
}

// Isi modal untuk edit
function editAnnouncement(id, tajuk, kandungan, kategori, tarikh_tamat, gambar){
    openModal();
    document.getElementById('id_edit').value = id;
    document.getElementById('tajuk').value = tajuk;
    document.getElementById('kategori').value = kategori;
    document.getElementById('tarikh_tamat').value = tarikh_tamat;
    document.getElementById('old_gambar').value = gambar;
    if(editor) editor.setData(kandungan);
}

// Sync CKEditor sebelum submit
document.getElementById('modalForm').addEventListener('submit', function(){
    if(editor) editor.updateSourceElement();
});
</script>

</body>
</html>
