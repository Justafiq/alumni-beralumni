<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya admin boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Ambil semua pengguna
$query = "SELECT id_user, nama, tahun_alumni, kursus, pekerjaan, role, sambung_belajar, institusi, emel 
          FROM users ORDER BY tahun_alumni DESC, nama ASC";
$result = mysqli_query($conn, $query);

$alumniData = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $alumniData[] = $row;
    }
}

// Statistik
$totalUsers = count($alumniData);
$totalAlumni = count(array_filter($alumniData, fn($u)=>$u['role']=='alumni'));
$totalGuru = count(array_filter($alumniData, fn($u)=>$u['role']=='guru'));
$totalAdmin = count(array_filter($alumniData, fn($u)=>$u['role']=='admin'));

$alumniPerYear = [];
foreach ($alumniData as $u) {
    if ($u['tahun_alumni']) {
        if (!isset($alumniPerYear[$u['tahun_alumni']])) $alumniPerYear[$u['tahun_alumni']] = 0;
        $alumniPerYear[$u['tahun_alumni']]++;
    }
}

$sambungBelajar = ['Ya'=>0,'Tidak'=>0];
foreach ($alumniData as $u) {
    $sambungBelajar[$u['sambung_belajar']?'Ya':'Tidak']++;
}

// Statistik kursus
$kursusStats = []; 
foreach ($alumniData as $u) {
    if ($u['kursus'] && $u['role'] === 'alumni') {
        if (!isset($kursusStats[$u['kursus']])) $kursusStats[$u['kursus']] = 0;
        $kursusStats[$u['kursus']]++;
    }
}
arsort($kursusStats);
$topKursus = array_slice($kursusStats, 0, 5, true);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan & Statistik - Alumni System</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary': '#3B82F6',
                    'primary-dark': '#1D4ED8',
                    'accent': '#10B981',
                    'accent-dark': '#059669'
                }
            }
        }
    }
</script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    body { 
        font-family: 'Inter', sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .glass-effect {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.3s ease;
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }
    
    .fade-in {
        animation: fadeIn 0.8s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .pulse-animation {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.02); }
    }
    
    .chart-container {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.8) 100%);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
    }
    
    .loading-overlay {
        background: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(5px);
    }
    
    .table-row-hover {
        transition: all 0.2s ease;
    }
    
    .table-row-hover:hover {
        background: linear-gradient(90deg, #f8fafc 0%, #e2e8f0 100%);
        transform: scale(1.001);
    }
    
    .custom-scrollbar::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.1);
        border-radius: 10px;
    }
    
    .custom-scrollbar::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
</style>
</head>
<body class="min-h-screen p-4 sm:p-6">

<div class="max-w-7xl mx-auto">

    <!-- Enhanced Header -->
    <div class="glass-effect rounded-2xl shadow-2xl p-6 sm:p-8 mb-8 fade-in">
        <div class="flex flex-col lg:flex-row justify-between items-center">
            <div class="flex items-center space-x-6 mb-6 lg:mb-0">
                <div class="relative">
                    <div class="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <i class="fas fa-chart-line text-white text-3xl"></i>
                    </div>
                    <div class="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-white flex items-center justify-center">
                        <i class="fas fa-check text-white text-xs"></i>
                    </div>
                </div>
                <div>
                    <h1 class="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                        Laporan & Statistik
                    </h1>
                    <p class="text-lg text-gray-600 mt-1 flex items-center">
                        <i class="fas fa-chart-bar mr-2 text-purple-500"></i>
                        Analisis Data Pengguna Sistem
                    </p>
                </div>
            </div>
            
            <div class="flex flex-col sm:flex-row gap-3">
                <a href="admin_dashboard.php" class="px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-arrow-left"></i>
                    <span>Kembali</span>
                </a>
                <button id="print-btn" class="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-print"></i>
                    <span>Cetak</span>
                </button>
                <button id="export-btn" class="px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                    <i class="fas fa-download"></i>
                    <span>Export CSV</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Enhanced Statistics Cards -->
    <div class="stats-grid mb-8">
        <div class="glass-effect rounded-2xl p-8 card-hover fade-in">
            <div class="flex items-center justify-between mb-6">
                <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-users text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $totalUsers; ?></p>
                    <p class="text-gray-600 font-semibold">Total Pengguna</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-3">
                <div class="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full" style="width: 100%"></div>
            </div>
            <p class="text-sm text-gray-500 mt-2">Keseluruhan pengguna sistem</p>
        </div>
        
        <div class="glass-effect rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.1s">
            <div class="flex items-center justify-between mb-6">
                <div class="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-graduation-cap text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $totalAlumni; ?></p>
                    <p class="text-gray-600 font-semibold">Alumni</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-3">
                <div class="bg-gradient-to-r from-green-500 to-green-600 h-3 rounded-full" 
                     style="width: <?php echo $totalUsers > 0 ? ($totalAlumni / $totalUsers) * 100 : 0; ?>%"></div>
            </div>
            <p class="text-sm text-gray-500 mt-2"><?php echo $totalUsers > 0 ? round(($totalAlumni / $totalUsers) * 100, 1) : 0; ?>% daripada keseluruhan</p>
        </div>
        
        <div class="glass-effect rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.2s">
            <div class="flex items-center justify-between mb-6">
                <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-chalkboard-teacher text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $totalGuru; ?></p>
                    <p class="text-gray-600 font-semibold">Pensyarah</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-3">
                <div class="bg-gradient-to-r from-purple-500 to-purple-600 h-3 rounded-full" 
                     style="width: <?php echo $totalUsers > 0 ? ($totalGuru / $totalUsers) * 100 : 0; ?>%"></div>
            </div>
            <p class="text-sm text-gray-500 mt-2"><?php echo $totalUsers > 0 ? round(($totalGuru / $totalUsers) * 100, 1) : 0; ?>% daripada keseluruhan</p>
        </div>
        
        <div class="glass-effect rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.3s">
            <div class="flex items-center justify-between mb-6">
                <div class="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-user-shield text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $totalAdmin; ?></p>
                    <p class="text-gray-600 font-semibold">Administrator</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-3">
                <div class="bg-gradient-to-r from-orange-500 to-orange-600 h-3 rounded-full" 
                     style="width: <?php echo $totalUsers > 0 ? ($totalAdmin / $totalUsers) * 100 : 0; ?>%"></div>
            </div>
            <p class="text-sm text-gray-500 mt-2"><?php echo $totalUsers > 0 ? round(($totalAdmin / $totalUsers) * 100, 1) : 0; ?>% daripada keseluruhan</p>
        </div>
    </div>

    <!-- Enhanced Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8 mb-8">
        
        <!-- Alumni per Tahun Chart -->
        <div class="chart-container rounded-2xl shadow-xl p-6 card-hover fade-in" style="animation-delay: 0.4s">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-calendar-alt mr-3 text-blue-600"></i>
                    Alumni Mengikut Tahun
                </h2>
                <div class="text-sm text-gray-500 bg-blue-100 px-3 py-1 rounded-full">
                    <i class="fas fa-chart-bar mr-1"></i>
                    Bar Chart
                </div>
            </div>
            <div style="height: 300px;">
                <canvas id="alumni-year-chart"></canvas>
            </div>
        </div>

        <!-- Sambung Belajar Chart -->
        <div class="chart-container rounded-2xl shadow-xl p-6 card-hover fade-in" style="animation-delay: 0.5s">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-university mr-3 text-green-600"></i>
                    Status Sambung Belajar
                </h2>
                <div class="text-sm text-gray-500 bg-green-100 px-3 py-1 rounded-full">
                    <i class="fas fa-chart-pie mr-1"></i>
                    Pie Chart
                </div>
            </div>
            <div style="height: 300px;">
                <canvas id="sambung-chart"></canvas>
            </div>
        </div>

        <!-- Top Kursus Chart -->
        <div class="chart-container rounded-2xl shadow-xl p-6 card-hover fade-in lg:col-span-2 xl:col-span-1" style="animation-delay: 0.6s">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-trophy mr-3 text-yellow-600"></i>
                    Top 5 Kursus
                </h2>
                <div class="text-sm text-gray-500 bg-yellow-100 px-3 py-1 rounded-full">
                    <i class="fas fa-chart-line mr-1"></i>
                    Doughnut
                </div>
            </div>
            <div style="height: 300px;">
                <canvas id="kursus-chart"></canvas>
            </div>
        </div>
    </div>

    <!-- Enhanced Filters -->
    <div class="glass-effect rounded-2xl shadow-xl p-6 mb-8 fade-in" style="animation-delay: 0.7s">
        <div class="flex items-center mb-6">
            <i class="fas fa-filter text-blue-600 text-xl mr-3"></i>
            <h2 class="text-xl font-bold text-gray-800">Filter Data Laporan</h2>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <div class="relative">
                <label for="role-filter" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-user-tag mr-1"></i>
                    Peranan
                </label>
                <select id="role-filter" class="w-full p-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                    <option value="all">Semua Peranan</option>
                    <option value="alumni">Alumni</option>
                    <option value="guru">Pensyarah</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
            
            <div class="relative">
                <label for="year-filter" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-calendar mr-1"></i>
                    Tahun Alumni
                </label>
                <select id="year-filter" class="w-full p-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                    <option value="all">Semua Tahun</option>
                </select>
            </div>
            
            <div class="relative">
                <label for="sambung-filter" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-university mr-1"></i>
                    Sambung Belajar
                </label>
                <select id="sambung-filter" class="w-full p-3 border border-gray-200 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300">
                    <option value="all">Semua Status</option>
                    <option value="ya">Ya</option>
                    <option value="tidak">Tidak</option>
                </select>
            </div>
            
            <div class="flex items-end">
                <button id="filter-btn" class="w-full py-3 btn-gradient text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center space-x-2">
                    <i class="fas fa-search"></i>
                    <span>Tapis Data</span>
                </button>
            </div>
        </div>
        
        <div class="mt-4 flex items-center justify-between">
            <p id="total-filtered" class="text-gray-600 font-medium">
                <i class="fas fa-info-circle mr-2"></i>
                Menunjukkan <span class="font-bold">0</span> daripada <span class="font-bold"><?php echo $totalUsers; ?></span> pengguna
            </p>
            <button id="reset-filter" class="text-blue-600 hover:text-blue-800 font-medium flex items-center space-x-1 transition-colors duration-300">
                <i class="fas fa-undo"></i>
                <span>Reset Filter</span>
            </button>
        </div>
    </div>

    <!-- Enhanced Table -->
    <div class="glass-effect rounded-2xl shadow-xl p-6 fade-in" style="animation-delay: 0.8s">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-gray-800 flex items-center">
                <i class="fas fa-table mr-3 text-purple-600"></i>
                Data Pengguna Terperinci
            </h2>
            <div class="flex items-center space-x-2">
                <span class="text-sm text-gray-500">Jumlah:</span>
                <span id="table-count" class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full font-semibold">0</span>
            </div>
        </div>
        
        <!-- Loading Overlay -->
        <div id="loading-overlay" class="hidden absolute inset-0 loading-overlay flex items-center justify-center rounded-2xl">
            <div class="text-center">
                <div class="animate-spin w-12 h-12 border-4 border-blue-200 border-t-blue-600 rounded-full mx-auto mb-4"></div>
                <p class="text-gray-600 font-medium">Memuat data...</p>
            </div>
        </div>
        
        <div class="overflow-x-auto custom-scrollbar rounded-xl border border-gray-200 shadow-sm">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gradient-to-r from-purple-600 to-pink-600">
                    <tr>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-user mr-2"></i>Nama
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-calendar mr-2"></i>Tahun
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-book mr-2"></i>Kursus
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-briefcase mr-2"></i>Pekerjaan
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-user-tag mr-2"></i>Peranan
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-university mr-2"></i>Sambung Belajar
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-building mr-2"></i>Institusi
                        </th>
                        <th class="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">
                            <i class="fas fa-envelope mr-2"></i>Email
                        </th>
                    </tr>
                </thead>
                <tbody id="report-table-body" class="bg-white divide-y divide-gray-200"></tbody>
            </table>
        </div>
        
        <!-- Empty State -->
        <div id="empty-state" class="hidden text-center py-16">
            <i class="fas fa-search text-gray-300 text-6xl mb-6"></i>
            <h3 class="text-2xl font-bold text-gray-600 mb-3">Tiada Data Ditemui</h3>
            <p class="text-gray-500 mb-6">Cuba ubah kriteria filter anda untuk melihat hasil yang berbeza.</p>
            <button id="clear-filter" class="px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold transition-all duration-300">
                Kosongkan Filter
            </button>
        </div>
    </div>

</div>

<script>
const alumniData = <?php echo json_encode($alumniData); ?>;
const tableBody = document.getElementById('report-table-body');
const roleFilter = document.getElementById('role-filter');
const yearFilter = document.getElementById('year-filter');
const sambungFilter = document.getElementById('sambung-filter');
const filterBtn = document.getElementById('filter-btn');
const resetFilterBtn = document.getElementById('reset-filter');
const exportBtn = document.getElementById('export-btn');
const printBtn = document.getElementById('print-btn');
const totalFilteredEl = document.getElementById('total-filtered');
const tableCountEl = document.getElementById('table-count');
const emptyState = document.getElementById('empty-state');
const loadingOverlay = document.getElementById('loading-overlay');

let currentData = alumniData;

// Populate filters
const years = [...new Set(alumniData.map(a => a.tahun_alumni).filter(y => y))].sort();
years.forEach(y => {
    const option = document.createElement('option');
    option.value = y;
    option.textContent = y;
    yearFilter.appendChild(option);
});

// Enhanced table rendering with animations
function renderTable(data) {
    loadingOverlay.classList.remove('hidden');
    tableBody.innerHTML = '';
    emptyState.classList.add('hidden');
    
    setTimeout(() => {
        loadingOverlay.classList.add('hidden');
        
        if (data.length === 0) {
            emptyState.classList.remove('hidden');
            tableCountEl.textContent = '0';
            updateFilterStatus(0);
            return;
        }
        
        data.forEach((item, index) => {
            const row = document.createElement('tr');
            row.className = 'table-row-hover';
            row.style.animationDelay = `${index * 0.05}s`;
            
            // Role badge styling
            let roleClass = '';
            let roleIcon = '';
            switch(item.role) {
                case 'alumni':
                    roleClass = 'bg-green-100 text-green-800';
                    roleIcon = 'fas fa-graduation-cap';
                    break;
                case 'guru':
                    roleClass = 'bg-purple-100 text-purple-800';
                    roleIcon = 'fas fa-chalkboard-teacher';
                    break;
                case 'admin':
                    roleClass = 'bg-orange-100 text-orange-800';
                    roleIcon = 'fas fa-user-shield';
                    break;
            }
            
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm mr-3">
                            ${item.nama.charAt(0).toUpperCase()}
                        </div>
                        <div class="text-sm font-semibold text-gray-900">${item.nama}</div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium">${item.tahun_alumni || '-'}</span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.kursus || '-'}">
                    ${item.kursus || '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.pekerjaan || '-'}">
                    ${item.pekerjaan || '-'}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold ${roleClass}">
                        <i class="${roleIcon} mr-1"></i>
                        ${item.role.charAt(0).toUpperCase() + item.role.slice(1)}
                    </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${item.sambung_belajar ? 
                        '<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800"><i class="fas fa-check mr-1"></i>Ya</span>' : 
                        '<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800"><i class="fas fa-times mr-1"></i>Tidak</span>'
                    }
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.institusi || '-'}">
                    ${item.institusi || '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-600 max-w-xs truncate" title="${item.emel || '-'}">
                    ${item.emel || '-'}
                </td>
            `;
            
            row.classList.add('fade-in');
            tableBody.appendChild(row);
        });
        
        tableCountEl.textContent = data.length;
        updateFilterStatus(data.length);
    }, 500);
}

// Update filter status
function updateFilterStatus(count) {
    totalFilteredEl.innerHTML = `
        <i class="fas fa-info-circle mr-2"></i>
        Menunjukkan <span class="font-bold text-blue-600">${count}</span> daripada <span class="font-bold"><?php echo $totalUsers; ?></span> pengguna
    `;
}

// Enhanced filter function
function filterTable() {
    let filtered = alumniData;
    const role = roleFilter.value;
    const year = yearFilter.value;
    const sambung = sambungFilter.value;

    if (role !== 'all') {
        filtered = filtered.filter(a => a.role === role);
    }
    if (year !== 'all') {
        filtered = filtered.filter(a => a.tahun_alumni && a.tahun_alumni.toString() === year);
    }
    if (sambung !== 'all') {
        if (sambung === 'ya') {
            filtered = filtered.filter(a => a.sambung_belajar);
        } else {
            filtered = filtered.filter(a => !a.sambung_belajar);
        }
    }

    currentData = filtered;
    renderTable(filtered);
}

// Reset filters
function resetFilters() {
    roleFilter.value = 'all';
    yearFilter.value = 'all';
    sambungFilter.value = 'all';
    currentData = alumniData;
    renderTable(alumniData);
}

// Event listeners
filterBtn.addEventListener('click', filterTable);
resetFilterBtn.addEventListener('click', resetFilters);
document.getElementById('clear-filter').addEventListener('click', resetFilters);

// Export CSV with current filtered data
exportBtn.addEventListener('click', () => {
    const csv = convertToCSV(currentData);
    downloadCSV(csv, 'laporan_pengguna.csv');
});

// Print functionality
printBtn.addEventListener('click', () => {
    window.print();
});

// CSV functions
function convertToCSV(data) {
    const headers = ['Nama','Tahun Alumni','Kursus','Pekerjaan','Peranan','Sambung Belajar','Institusi','Email'];
    const rows = data.map(r => [
        `"${r.nama || ''}"`,
        `"${r.tahun_alumni || ''}"`,
        `"${r.kursus || ''}"`,
        `"${r.pekerjaan || ''}"`,
        `"${r.role || ''}"`,
        `"${r.sambung_belajar ? 'Ya':'Tidak'}"`,
        `"${r.institusi || ''}"`,
        `"${r.emel || ''}"`
    ].join(','));
    return [headers.join(','), ...rows].join('\n');
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Animate numbers on page load
document.addEventListener('DOMContentLoaded', function() {
    const numbers = document.querySelectorAll('.pulse-animation');
    numbers.forEach(number => {
        const target = parseInt(number.textContent);
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            number.textContent = Math.floor(current);
        }, 30);
    });
});

// Initial render
renderTable(alumniData);

// Enhanced Charts with modern styling
Chart.defaults.font.family = 'Inter';
Chart.defaults.font.size = 12;
Chart.defaults.color = '#6B7280';

// Alumni per Year Chart
const alumniYearChart = new Chart(document.getElementById('alumni-year-chart'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_keys($alumniPerYear)); ?>,
        datasets: [{
            label: 'Jumlah Alumni',
            data: <?php echo json_encode(array_values($alumniPerYear)); ?>,
            backgroundColor: 'rgba(59, 130, 246, 0.8)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 2,
            borderRadius: 8,
            borderSkipped: false,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                backgroundColor: 'rgba(17, 24, 39, 0.9)',
                titleColor: '#F9FAFB',
                bodyColor: '#F9FAFB',
                borderColor: 'rgba(59, 130, 246, 0.2)',
                borderWidth: 1,
                cornerRadius: 12,
                displayColors: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0, 0, 0, 0.05)'
                },
                ticks: {
                    color: '#6B7280'
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#6B7280'
                }
            }
        }
    }
});

// Sambung Belajar Pie Chart
const sambungChart = new Chart(document.getElementById('sambung-chart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_keys($sambungBelajar)); ?>,
        datasets: [{
            data: <?php echo json_encode(array_values($sambungBelajar)); ?>,
            backgroundColor: [
                'rgba(16, 185, 129, 0.8)',
                'rgba(245, 158, 11, 0.8)'
            ],
            borderColor: [
                'rgba(16, 185, 129, 1)',
                'rgba(245, 158, 11, 1)'
            ],
            borderWidth: 3,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 20,
                    usePointStyle: true,
                    font: {
                        size: 14,
                        weight: '500'
                    }
                }
            },
            tooltip: {
                backgroundColor: 'rgba(17, 24, 39, 0.9)',
                titleColor: '#F9FAFB',
                bodyColor: '#F9FAFB',
                borderColor: 'rgba(16, 185, 129, 0.2)',
                borderWidth: 1,
                cornerRadius: 12,
                callbacks: {
                    label: function(context) {
                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                        const percentage = ((context.raw / total) * 100).toFixed(1);
                        return `${context.label}: ${context.raw} (${percentage}%)`;
                    }
                }
            }
        }
    }
});

// Top Kursus Doughnut Chart
const kursusChart = new Chart(document.getElementById('kursus-chart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_keys($topKursus)); ?>,
        datasets: [{
            data: <?php echo json_encode(array_values($topKursus)); ?>,
            backgroundColor: [
                'rgba(168, 85, 247, 0.8)',
                'rgba(236, 72, 153, 0.8)',
                'rgba(34, 197, 94, 0.8)',
                'rgba(249, 115, 22, 0.8)',
                'rgba(59, 130, 246, 0.8)'
            ],
            borderColor: [
                'rgba(168, 85, 247, 1)',
                'rgba(236, 72, 153, 1)',
                'rgba(34, 197, 94, 1)',
                'rgba(249, 115, 22, 1)',
                'rgba(59, 130, 246, 1)'
            ],
            borderWidth: 3,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '50%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 15,
                    usePointStyle: true,
                    font: {
                        size: 12,
                        weight: '500'
                    },
                    generateLabels: function(chart) {
                        const data = chart.data;
                        if (data.labels.length && data.datasets.length) {
                            return data.labels.map((label, i) => {
                                const value = data.datasets[0].data[i];
                                return {
                                    text: `${label.length > 15 ? label.substring(0, 15) + '...' : label} (${value})`,
                                    fillStyle: data.datasets[0].backgroundColor[i],
                                    strokeStyle: data.datasets[0].borderColor[i],
                                    lineWidth: 2,
                                    pointStyle: 'circle',
                                    hidden: false,
                                    index: i
                                };
                            });
                        }
                        return [];
                    }
                }
            },
            tooltip: {
                backgroundColor: 'rgba(17, 24, 39, 0.9)',
                titleColor: '#F9FAFB',
                bodyColor: '#F9FAFB',
                borderColor: 'rgba(168, 85, 247, 0.2)',
                borderWidth: 1,
                cornerRadius: 12,
                callbacks: {
                    label: function(context) {
                        return `${context.label}: ${context.raw} alumni`;
                    }
                }
            }
        }
    }
});
</script>

<!-- Print Styles -->
<style media="print">
    @page {
        margin: 1cm;
        size: A4;
    }
    
    body {
        background: white !important;
        -webkit-print-color-adjust: exact;
    }
    
    .glass-effect {
        background: white !important;
        border: 1px solid #e5e7eb !important;
        box-shadow: none !important;
    }
    
    .btn-gradient, .bg-gradient-to-br, .bg-gradient-to-r {
        background: #3B82F6 !important;
        color: white !important;
    }
    
    .fade-in {
        animation: none !important;
    }
    
    .card-hover:hover {
        transform: none !important;
    }
    
    canvas {
        max-height: 300px !important;
    }
</style>

</body>
</html>