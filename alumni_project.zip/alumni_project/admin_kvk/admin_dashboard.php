<?php
session_start();
include("../include/connection.php"); // ✅ FIXED PATH

// ====== LOGOUT FUNCTION ======
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: ../login.php"); // balik ke root login
    exit();
}

// ====== CHECK ROLE ======
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit();
}

// ====== DATA ======
// kira jumlah user berdasarkan role
$total_admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='admin'"))['total'];
$total_pensyarah = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='guru'"))['total'];
$total_alumni = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE role='alumni'"))['total'];
$total_users = $total_admin + $total_pensyarah + $total_alumni;

// Get recent users (without created_at column since it doesn't exist)
$recent_users_query = "SELECT nama, role FROM users ORDER BY id_user DESC LIMIT 5";
$recent_users_result = mysqli_query($conn, $recent_users_query);
$recent_users = [];
if ($recent_users_result) {
    while ($row = mysqli_fetch_assoc($recent_users_result)) {
        $recent_users[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard Alumni</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary': '#3B82F6',
                    'primary-dark': '#1D4ED8',
                    'accent': '#10B981',
                    'accent-dark': '#059669'
                }
            }
        }
    }
  </script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    body { 
        font-family: 'Inter', sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .glass-effect {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.3s ease;
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }
    
    .fade-in {
        animation: fadeIn 0.8s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .pulse-animation {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    .gradient-text {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }
    
    .navbar-glass {
        background: rgba(17, 24, 39, 0.95);
        backdrop-filter: blur(10px);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .stats-card {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
    }
    
    .stats-card:hover {
        transform: translateY(-8px) rotate(1deg);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    }
  </style>
</head>
<body class="min-h-screen">

  <!-- Enhanced Navbar -->
  <nav class="navbar-glass shadow-2xl sticky top-0 z-50">
    <div class="container mx-auto px-6 py-4">
      <div class="flex justify-between items-center">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <i class="fas fa-graduation-cap text-white text-xl"></i>
          </div>
          <div>
            <h1 class="text-white text-2xl font-bold">Admin Dashboard</h1>
            <p class="text-gray-300 text-sm">Sistem Pengurusan Alumni</p>
          </div>
        </div>
        
        <div class="hidden md:flex items-center space-x-6">
          <a class="text-white hover:text-blue-300 px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 bg-white bg-opacity-10" href="admin_dashboard.php">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
          <a class="text-gray-300 hover:text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 hover:bg-white hover:bg-opacity-10" href="data_pengguna.php">
            <i class="fas fa-users"></i>
            <span>Data Pengguna</span>
          </a>
          <a class="text-gray-300 hover:text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 hover:bg-white hover:bg-opacity-10" href="announcements.php">
            <i class="fas fa-bullhorn"></i>
            <span>Pengumuman</span>
          </a>
        </div>
        
        <div class="flex items-center space-x-4">
          <div class="text-white text-right hidden sm:block">
            <p class="text-sm font-medium">Selamat Datang</p>
            <p class="text-xs text-gray-300">Administrator</p>
          </div>
          <a href="admin_dashboard.php?logout=true" 
             class="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-xl transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl">
             <i class="fas fa-sign-out-alt"></i>
             <span>Log Keluar</span>
          </a>
        </div>
      </div>
    </div>
  </nav>

  <!-- Hero Section -->
  <div class="py-16 px-6 fade-in">
    <div class="max-w-6xl mx-auto text-center">
      <div class="mb-8">
        <h1 class="text-5xl sm:text-6xl font-bold text-white mb-4">
          <i class="fas fa-chart-line mr-4"></i>
          Dashboard Statistik
        </h1>
        <p class="text-xl text-white opacity-90 max-w-3xl mx-auto">
          Pantau dan urus sistem alumni dengan dashboard yang komprehensif dan mudah digunakan
        </p>
      </div>
      
      <!-- Quick Actions -->
      <div class="flex flex-wrap justify-center gap-4 mb-12">
        <a href="data_pengguna.php" class="btn-gradient text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl flex items-center space-x-2">
          <i class="fas fa-users"></i>
          <span>Urus Pengguna</span>
        </a>
        <a href="tambah_user.php" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
          <i class="fas fa-plus"></i>
          <span>Tambah Pengguna</span>
        </a>
        <a href="reports.php" class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
          <i class="fas fa-chart-bar"></i>
          <span>Export CSV</span>
        </a>
      </div>
    </div>
  </div>

  <!-- Main Content -->
  <main class="max-w-7xl mx-auto px-6 pb-16">
    
    <!-- Stats Cards -->
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
      <!-- Total Users -->
      <div class="stats-card rounded-2xl p-8 card-hover fade-in">
        <div class="flex items-center justify-between mb-4">
          <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
            <i class="fas fa-users text-white text-2xl"></i>
          </div>
          <div class="text-right">
            <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $total_users; ?></p>
            <p class="text-gray-600 font-medium">Total Pengguna</p>
          </div>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2">
          <div class="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full" style="width: 100%"></div>
        </div>
      </div>
      
      <!-- Alumni -->
      <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.1s">
        <div class="flex items-center justify-between mb-4">
          <div class="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
            <i class="fas fa-graduation-cap text-white text-2xl"></i>
          </div>
          <div class="text-right">
            <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $total_alumni; ?></p>
            <p class="text-gray-600 font-medium">Alumni</p>
          </div>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2">
          <div class="bg-gradient-to-r from-green-500 to-green-600 h-2 rounded-full" 
               style="width: <?php echo $total_users > 0 ? ($total_alumni / $total_users) * 100 : 0; ?>%"></div>
        </div>
      </div>
      
      <!-- Pensyarah -->
      <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.2s">
        <div class="flex items-center justify-between mb-4">
          <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
            <i class="fas fa-chalkboard-teacher text-white text-2xl"></i>
          </div>
          <div class="text-right">
            <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $total_pensyarah; ?></p>
            <p class="text-gray-600 font-medium">Pensyarah</p>
          </div>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2">
          <div class="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full" 
               style="width: <?php echo $total_users > 0 ? ($total_pensyarah / $total_users) * 100 : 0; ?>%"></div>
        </div>
      </div>
      
      <!-- Admin -->
      <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.3s">
        <div class="flex items-center justify-between mb-4">
          <div class="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
            <i class="fas fa-user-shield text-white text-2xl"></i>
          </div>
          <div class="text-right">
            <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $total_admin; ?></p>
            <p class="text-gray-600 font-medium">Admin</p>
          </div>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2">
          <div class="bg-gradient-to-r from-orange-500 to-orange-600 h-2 rounded-full" 
               style="width: <?php echo $total_users > 0 ? ($total_admin / $total_users) * 100 : 0; ?>%"></div>
        </div>
      </div>
    </section>

    <!-- Dashboard Grid -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-8">
      
      <!-- Recent Activities -->
      <div class="glass-effect rounded-2xl p-8 shadow-2xl fade-in" style="animation-delay: 0.4s">
        <div class="flex items-center justify-between mb-6">
          <h3 class="text-2xl font-bold text-gray-800 flex items-center">
            <i class="fas fa-clock mr-3 text-blue-600"></i>
            Aktiviti Terkini
          </h3>
          <a href="data_pengguna.php" class="text-blue-600 hover:text-blue-800 font-medium flex items-center space-x-1">
            <span>Lihat Semua</span>
            <i class="fas fa-arrow-right"></i>
          </a>
        </div>
        
        <div class="space-y-4">
          <?php if (!empty($recent_users)): ?>
            <?php foreach ($recent_users as $user): ?>
              <div class="flex items-center p-4 bg-white bg-opacity-50 rounded-xl hover:bg-opacity-70 transition-all duration-300">
                <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold mr-4">
                  <?php echo strtoupper(substr($user['nama'], 0, 1)); ?>
                </div>
                <div class="flex-1">
                  <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($user['nama']); ?></p>
                  <p class="text-sm text-gray-600">
                    <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      <?php echo ucfirst($user['role']); ?>
                    </span>
                  </p>
                </div>
                <div class="text-right">
                  <p class="text-sm text-gray-500">
                    Pengguna Baru
                  </p>
                </div>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="text-center py-8">
              <i class="fas fa-users text-gray-300 text-4xl mb-4"></i>
              <p class="text-gray-500">Tiada aktiviti terkini</p>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- Quick Actions Panel -->
      <div class="glass-effect rounded-2xl p-8 shadow-2xl fade-in" style="animation-delay: 0.5s">
        <h3 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
          <i class="fas fa-bolt mr-3 text-yellow-500"></i>
          Tindakan Pantas
        </h3>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <a href="data_pengguna.php" class="group p-6 bg-white bg-opacity-50 rounded-xl hover:bg-opacity-70 transition-all duration-300 text-center card-hover">
            <div class="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-blue-200">
              <i class="fas fa-users text-blue-600 text-xl"></i>
            </div>
            <h4 class="font-semibold text-gray-800 mb-2">Urus Pengguna</h4>
            <p class="text-sm text-gray-600">Lihat dan edit data pengguna</p>
          </a>
          
          <a href="tambah_user.php" class="group p-6 bg-white bg-opacity-50 rounded-xl hover:bg-opacity-70 transition-all duration-300 text-center card-hover">
            <div class="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-green-200">
              <i class="fas fa-plus text-green-600 text-xl"></i>
            </div>
            <h4 class="font-semibold text-gray-800 mb-2">Tambah Pengguna</h4>
            <p class="text-sm text-gray-600">Daftar pengguna baru</p>
          </a>
          
          <a href="reports.php" class="group p-6 bg-white bg-opacity-50 rounded-xl hover:bg-opacity-70 transition-all duration-300 text-center card-hover">
            <div class="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-purple-200">
              <i class="fas fa-chart-bar text-purple-600 text-xl"></i>
            </div>
            <h4 class="font-semibold text-gray-800 mb-2">Laporan</h4>
            <p class="text-sm text-gray-600">Statistik dan analisis</p>
          </a>
          
          <a href="settings.php" class="group p-6 bg-white bg-opacity-50 rounded-xl hover:bg-opacity-70 transition-all duration-300 text-center card-hover">
            <div class="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center mx-auto mb-3 group-hover:bg-gray-200">
              <i class="fas fa-cog text-gray-600 text-xl"></i>
            </div>
            <h4 class="font-semibold text-gray-800 mb-2">Tetapan</h4>
            <p class="text-sm text-gray-600">Konfigurasi sistem</p>
          </a>
        </div>
      </div>
      
    </section>
  </main>

  <!-- Enhanced Footer -->
  <footer class="navbar-glass mt-16 py-8">
    <div class="max-w-6xl mx-auto px-6 text-center">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <div class="flex items-center space-x-3 mb-4 md:mb-0">
          <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <i class="fas fa-graduation-cap text-white"></i>
          </div>
          <span class="text-white font-semibold">Sistem Alumni</span>
        </div>
        <p class="text-gray-300 text-sm">
          &copy; 2025 Projek Alumni. Hak cipta terpelihara.
        </p>
        <div class="flex items-center space-x-4 mt-4 md:mt-0">
          <span class="text-gray-400 text-sm">Dibina dengan Aiman Company Sdn Bhd.</span>
          
        </div>
      </div>
    </div>
  </footer>

  <script>
    // Add some interactive animations
    document.addEventListener('DOMContentLoaded', function() {
      // Animate numbers
      const numbers = document.querySelectorAll('.pulse-animation');
      numbers.forEach(number => {
        const target = parseInt(number.textContent);
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
          current += increment;
          if (current >= target) {
            current = target;
            clearInterval(timer);
          }
          number.textContent = Math.floor(current);
        }, 30);
      });
      
      // Add hover effects to cards
      const cards = document.querySelectorAll('.card-hover');
      cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
          this.style.transform = 'translateY(-8px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
          this.style.transform = 'translateY(0) scale(1)';
        });
      });
    });
  </script>

</body>
</html>