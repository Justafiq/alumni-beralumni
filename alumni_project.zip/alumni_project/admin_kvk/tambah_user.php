<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya admin boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

$success = "";
$error = "";

if (isset($_POST['submit'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $tahun = mysqli_real_escape_string($conn, $_POST['tahun_alumni']);
    $kursus = mysqli_real_escape_string($conn, $_POST['kursus']);
    $pekerjaan = mysqli_real_escape_string($conn, $_POST['pekerjaan']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $sambung_belajar = mysqli_real_escape_string($conn, $_POST['sambung_belajar']);
    $institusi = mysqli_real_escape_string($conn, $_POST['institusi']);
    $emel = mysqli_real_escape_string($conn, $_POST['emel']);
    $katalaluan = password_hash($_POST['katalaluan'], PASSWORD_DEFAULT);

    // Semak email unik
    $check = mysqli_query($conn, "SELECT * FROM users WHERE emel='$emel'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Email sudah wujud!";
    } else {
        $insert = "INSERT INTO users (nama, tahun_alumni, kursus, pekerjaan, role, sambung_belajar, institusi, emel, katalaluan)
                   VALUES ('$nama', '$tahun', '$kursus', '$pekerjaan', '$role', '$sambung_belajar', '$institusi', '$emel', '$katalaluan')";
        if (mysqli_query($conn, $insert)) {
            $success = "Pengguna berjaya ditambah!";
        } else {
            $error = "Ralat semasa menambah pengguna: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Pengguna</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap');
    body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; }
    .container { max-width: 700px; }
</style>
</head>
<body class="bg-gray-100 p-4 sm:p-8">

<div class="container mx-auto bg-white rounded-lg shadow-lg p-6 sm:p-8">

    <!-- Header -->
    <header class="flex justify-between items-center mb-6 border-b pb-4">
        <h1 class="text-2xl font-bold text-gray-800">Tambah Pengguna</h1>
        <a href="data_pengguna.php" class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">Kembali</a>
    </header>

    <?php if($success): ?>
        <p class="mb-4 p-3 bg-green-100 text-green-800 rounded"><?php echo $success; ?></p>
    <?php endif; ?>
    <?php if($error): ?>
        <p class="mb-4 p-3 bg-red-100 text-red-800 rounded"><?php echo $error; ?></p>
    <?php endif; ?>

    <form method="POST" class="space-y-4">

        <div>
            <label class="block text-gray-700 font-medium">Nama:</label>
            <input type="text" name="nama" required class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Tahun Alumni:</label>
            <input type="number" name="tahun_alumni" min="1900" max="2100" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Kursus:</label>
            <input type="text" name="kursus" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Pekerjaan:</label>
            <input type="text" name="pekerjaan" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Peranan:</label>
            <select name="role" required class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="alumni">Alumni</option>
                <option value="guru">Guru</option>
                <option value="admin">Admin</option>
            </select>
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Sambung Belajar:</label>
            <input type="text" name="sambung_belajar" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Institusi:</label>
            <input type="text" name="institusi" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Email:</label>
            <input type="email" name="emel" required class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div>
            <label class="block text-gray-700 font-medium">Katalaluan:</label>
            <input type="password" name="katalaluan" required class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <button type="submit" name="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Tambah Pengguna</button>

    </form>
</div>
</body>
</html>
