<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya admin boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "admin") {
    header("Location: ../login.php");
    exit();
}

// Pastikan ada ID dihantar
if (!isset($_GET['id'])) {
    echo "ID pengguna tidak disertakan.";
    exit();
}

$id_user = intval($_GET['id']);

// Ambil data pengguna dari DB
$query = "SELECT * FROM users WHERE id_user = $id_user";
$result = mysqli_query($conn, $query);
if (!$result || mysqli_num_rows($result) === 0) {
    echo "Pengguna tidak ditemui.";
    exit();
}
$user = mysqli_fetch_assoc($result);

// Jika borang disubmit
if (isset($_POST['submit'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $tahun = mysqli_real_escape_string($conn, $_POST['tahun_alumni']);
    $kursus = mysqli_real_escape_string($conn, $_POST['kursus']);
    $pekerjaan = mysqli_real_escape_string($conn, $_POST['pekerjaan']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $sambung = mysqli_real_escape_string($conn, $_POST['sambung_belajar']);
    $institusi = mysqli_real_escape_string($conn, $_POST['institusi']);
    $emel = mysqli_real_escape_string($conn, $_POST['emel']);

    $updateQuery = "UPDATE users SET 
                    nama='$nama',
                    tahun_alumni='$tahun',
                    kursus='$kursus',
                    pekerjaan='$pekerjaan',
                    role='$role',
                    sambung_belajar='$sambung',
                    institusi='$institusi',
                    emel='$emel'
                    WHERE id_user=$id_user";
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Data berjaya dikemaskini'); window.location='data_pengguna.php';</script>";
        exit();
    } else {
        echo "Ralat: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Pengguna</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-4 sm:p-8">
<div class="max-w-xl mx-auto bg-white rounded-lg shadow-lg p-6 sm:p-8">
    <h1 class="text-2xl font-bold mb-4">Edit Pengguna</h1>
    <form method="POST" class="space-y-4">
        <div>
            <label class="block text-gray-700">Nama:</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Tahun Alumni:</label>
            <input type="number" name="tahun_alumni" value="<?= $user['tahun_alumni'] ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Kursus:</label>
            <input type="text" name="kursus" value="<?= htmlspecialchars($user['kursus']) ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Pekerjaan:</label>
            <input type="text" name="pekerjaan" value="<?= htmlspecialchars($user['pekerjaan']) ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Peranan:</label>
            <select name="role" class="w-full p-2 border rounded">
                <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
                <option value="guru" <?= $user['role']=='guru'?'selected':'' ?>>Guru</option>
                <option value="alumni" <?= $user['role']=='alumni'?'selected':'' ?>>Alumni</option>
            </select>
        </div>
        <div>
            <label class="block text-gray-700">Sambung Belajar:</label>
            <input type="text" name="sambung_belajar" value="<?= htmlspecialchars($user['sambung_belajar']) ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Institusi:</label>
            <input type="text" name="institusi" value="<?= htmlspecialchars($user['institusi']) ?>" class="w-full p-2 border rounded">
        </div>
        <div>
            <label class="block text-gray-700">Email:</label>
            <input type="email" name="emel" value="<?= htmlspecialchars($user['emel']) ?>" class="w-full p-2 border rounded">
        </div>
        <div class="flex justify-between items-center">
            <a href="data_pengguna.php" class="px-4 py-2 bg-gray-400 text-white rounded hover:bg-gray-500">Kembali</a>
            <button type="submit" name="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Simpan</button>
        </div>
    </form>
</div>
</body>
</html>
