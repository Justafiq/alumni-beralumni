<?php
$host = "localhost";
$user = "root";
$pass = ""; // kosong kalau XAMPP default
$db   = "alumni_project"; // ubah ikut nama database sebenar

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
