<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan user login (guru/alumni sahaja)
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ["guru", "alumni"])) {
    header("Location: ../login.php");
    exit();
}

$user_id   = $_SESSION['user_id']; 
$user_role = $_SESSION['role'];

// ✅ Dapatkan ID post
if (!isset($_GET['id'])) {
    header("Location: " . ($user_role == "guru" ? "../guru_kvk/guru_dashboard.php" : "../alumni_kvk/alumni_dashboard.php"));
    exit();
}
$post_id = intval($_GET['id']);

// ✅ Ambil post forum
$sql = "SELECT f.*, u.nama 
        FROM forum f
        JOIN users u ON f.created_by = u.id_user
        WHERE f.id_forum = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$post_result = $stmt->get_result();

if ($post_result->num_rows == 0) {
    die("❌ Post tidak dijumpai.");
}
$post = $post_result->fetch_assoc();

// ✅ Tambah komen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['komen'])) {
    $komen = trim($_POST['komen']);
    if (!empty($komen)) {
        $insert = "INSERT INTO forum_reply (id_forum, user_id, reply, created_at) 
                   VALUES (?, ?, ?, NOW())";
        $stmt = $conn->prepare($insert);
        $stmt->bind_param("iis", $post_id, $user_id, $komen);
        $stmt->execute();

        header("Location: forum_view.php?id=" . $post_id);
        exit();
    }
}

// ✅ Ambil komen
$komen_sql = "SELECT r.*, u.nama 
              FROM forum_reply r 
              JOIN users u ON r.user_id = u.id_user
              WHERE r.id_forum = ?
              ORDER BY r.created_at ASC";
$stmt = $conn->prepare($komen_sql);
$stmt->bind_param("i", $post_id);
$stmt->execute();
$komen_result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($post['tajuk']) ?> - Forum</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Navbar -->
  <nav class="bg-white shadow-md p-4 flex justify-between items-center">
    <h1 class="text-lg font-bold text-gray-700">📌 Forum</h1>
    <a href="<?= ($user_role == 'guru' ? '../guru_kvk/guru_dashboard.php' : '../alumni_kvk/alumni_dashboard.php') ?>" 
       class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">⬅ Kembali</a>
  </nav>

  <!-- Post -->
  <main class="container mx-auto px-4 py-6">
    <div class="bg-white shadow-md rounded-lg p-6 mb-6">
      <?php if (!empty($post['gambar'])): ?>
        <img src="../uploads/<?= htmlspecialchars($post['gambar']) ?>" class="w-full h-64 object-cover rounded mb-4">
      <?php endif; ?>

      <h2 class="text-2xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($post['tajuk']) ?></h2>
      <p class="text-gray-600 mb-4"><?= nl2br(htmlspecialchars($post['kandungan'])) ?></p>
      <p class="text-sm text-gray-500">🖊 Dipost oleh: <?= htmlspecialchars($post['nama']) ?> | <?= date("d M Y H:i", strtotime($post['created_at'])) ?></p>
    </div>

    <!-- Komen Section -->
    <div class="bg-white shadow-md rounded-lg p-6">
      <h3 class="text-xl font-semibold mb-4">💬 Komen</h3>

      <!-- Senarai komen -->
      <div class="space-y-4 mb-4">
        <?php if ($komen_result->num_rows > 0): ?>
            <?php while ($komen = $komen_result->fetch_assoc()): ?>
              <div class="border-b pb-2 relative group">
                <p class="text-gray-800"><strong><?= htmlspecialchars($komen['nama']) ?>:</strong></p>
                <p class="text-gray-600"><?= nl2br(htmlspecialchars($komen['reply'])) ?></p>
                <p class="text-xs text-gray-400"><?= date("d M Y H:i", strtotime($komen['created_at'])) ?></p>

                <!-- ✅ Kebab menu untuk komen milik user sendiri -->
                <?php if ($komen['user_id'] == $user_id): ?>
                  <div class="absolute top-2 right-2">
                    <button onclick="toggleMenu(<?= $komen['id_reply'] ?>)" 
                            class="text-gray-500 hover:text-gray-700">⋮</button>
                    <div id="menu-<?= $komen['id_reply'] ?>" 
                         class="hidden absolute right-0 mt-2 w-28 bg-white border rounded shadow-md z-10">
                      <a href="forum_edit.php?id=<?= $komen['id_reply'] ?>&post=<?= $post_id ?>" 
                         class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">✏ Edit</a>
                      <a href="forum_delete.php?id=<?= $komen['id_reply'] ?>&post=<?= $post_id ?>" 
                         onclick="return confirm('Padam komen ini?')" 
                         class="block px-4 py-2 text-sm text-red-600 hover:bg-red-100">🗑 Delete</a>
                    </div>
                  </div>
                <?php endif; ?>
              </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-gray-500 italic">Belum ada komen.</p>
        <?php endif; ?>
      </div>

      <!-- Borang tambah komen -->
      <form method="POST" class="flex gap-2">
        <input type="text" name="komen" placeholder="Tulis komen anda..." 
               class="flex-1 border rounded px-3 py-2 focus:outline-none focus:ring focus:ring-blue-200" required>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Hantar</button>
      </form>
    </div>
  </main>

  <script>
    function toggleMenu(id) {
      const menu = document.getElementById("menu-" + id);
      menu.classList.toggle("hidden");
    }
  </script>
</body>
</html>
