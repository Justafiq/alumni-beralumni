<?php
session_start();
include("../include/connection.php");

// Pastikan hanya guru boleh akses
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$msg = "";

// Handle tambah event
if (isset($_POST['submit'])) {
    $tajuk = $_POST['tajuk'];
    $tarikh_mula = $_POST['tarikh_mula'];
    $tarikh_tamat = !empty($_POST['tarikh_tamat']) ? $_POST['tarikh_tamat'] : NULL;
    $lokasi = $_POST['lokasi'];
    $keterangan = $_POST['keterangan'];

    // Handle gambar upload
    $gambar = NULL;
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $gambar = 'event_' . time() . '.' . $ext;
        move_uploaded_file($_FILES['gambar']['tmp_name'], '../uploads/events/' . $gambar);
    }

    $stmt = $conn->prepare("INSERT INTO events (tajuk, tarikh_mula, tarikh_tamat, lokasi, keterangan, gambar, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $tajuk, $tarikh_mula, $tarikh_tamat, $lokasi, $keterangan, $gambar, $user_id);
    if ($stmt->execute()) {
        $msg = "Event berjaya ditambah!";
    } else {
        $msg = "Ralat: " . $stmt->error;
    }
}

// Ambil semua events guru
$result = $conn->query("SELECT * FROM events WHERE created_by=$user_id ORDER BY tarikh_mula DESC");
$events = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Guru Events</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen p-4 bg-gray-100">

<div class="max-w-6xl mx-auto">

<!-- Header & Back button -->
<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold">Guru Events</h1>
    <a href="guru_dashboard.php" class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600 flex items-center">
        <i class="fas fa-arrow-left mr-2"></i>Kembali
    </a>
</div>

<!-- Pesan -->
<?php if($msg): ?>
<div class="mb-4 p-4 bg-green-200 text-green-800 rounded"><?php echo $msg; ?></div>
<?php endif; ?>

<!-- Form Tambah Event -->
<div class="bg-white p-6 rounded shadow mb-8">
    <form method="POST" enctype="multipart/form-data" class="space-y-4">
        <div>
            <label class="block font-semibold">Tajuk</label>
            <input type="text" name="tajuk" required class="w-full border p-2 rounded">
        </div>
        <div>
            <label class="block font-semibold">Tarikh Mula</label>
            <input type="datetime-local" name="tarikh_mula" required class="w-full border p-2 rounded">
        </div>
        <div>
            <label class="block font-semibold">Tarikh Tamat (optional)</label>
            <input type="datetime-local" name="tarikh_tamat" class="w-full border p-2 rounded">
        </div>
        <div>
            <label class="block font-semibold">Lokasi</label>
            <input type="text" name="lokasi" class="w-full border p-2 rounded">
        </div>
        <div>
            <label class="block font-semibold">Keterangan</label>
            <textarea name="keterangan" class="w-full border p-2 rounded"></textarea>
        </div>
        <div>
            <label class="block font-semibold">Gambar (optional)</label>
            <input type="file" name="gambar" accept="image/*" class="w-full">
        </div>
        <div>
            <button type="submit" name="submit" class="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Publish</button>
        </div>
    </form>
</div>

<!-- Senarai Events -->
<div class="bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4">Senarai Events</h2>
    <table class="w-full table-auto border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border p-2">Tajuk</th>
                <th class="border p-2">Tarikh Mula</th>
                <th class="border p-2">Tarikh Tamat</th>
                <th class="border p-2">Lokasi</th>
                <th class="border p-2">Gambar</th>
            </tr>
        </thead>
        <tbody>
        <?php if($events): ?>
            <?php foreach($events as $e): ?>
            <tr>
                <td class="border p-2"><?php echo $e['tajuk']; ?></td>
                <td class="border p-2"><?php echo $e['tarikh_mula']; ?></td>
                <td class="border p-2"><?php echo $e['tarikh_tamat'] ?: '-'; ?></td>
                <td class="border p-2"><?php echo $e['lokasi'] ?: '-'; ?></td>
                <td class="border p-2">
                    <?php if($e['gambar']): ?>
                        <img src="../uploads/events/<?php echo $e['gambar']; ?>" alt="Gambar" class="h-16">
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5" class="border p-2 text-center">Tiada events dijumpai.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

</div>
</body>
</html>
