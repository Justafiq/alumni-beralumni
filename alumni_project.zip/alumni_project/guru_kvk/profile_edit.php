<?php
session_start();
include("../include/connection.php");

// Pastikan login role guru
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data guru
$sql = "SELECT * FROM users WHERE id_user = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("Ralat: Maklumat profil tidak dijumpai.");
}

// Proses kemaskini
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'] ?? null;
    $umur = $_POST['umur'] ?? null;
    $kursus = $_POST['kursus'] ?? null;
    $bio = $_POST['bio'] ?? null;

    // Upload gambar (jika ada)
    $gambar = $user['gambar']; // default gambar lama
    if (!empty($_FILES['gambar']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }

        $fileName = time() . "_" . basename($_FILES['gambar']['name']);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetFile)) {
            $gambar = $fileName;
        }
    }

    $sql_update = "UPDATE users SET nama = ?, umur = ?, kursus = ?, bio = ?, gambar = ? WHERE id_user = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sisssi", $nama, $umur, $kursus, $bio, $gambar, $user_id);

    if ($stmt_update->execute()) {
        header("Location: profile_guru.php");
        exit();
    } else {
        $error = "Ralat semasa mengemaskini profil.";
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="flex justify-center items-center min-h-screen bg-gray-100 p-4">
    <div class="bg-white w-full max-w-2xl rounded-lg shadow-md p-6">
        <h1 class="text-2xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <i class="ph-pencil-fill text-blue-600"></i> Edit Profil Guru
        </h1>

        <?php if (!empty($error)): ?>
            <p class="text-red-500 mb-4"><?= $error ?></p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="space-y-5">
            <!-- Nama -->
            <div>
                <label for="nama" class="block text-sm font-medium text-slate-700">Nama</label>
                <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($user['nama'] ?? '') ?>" 
                       class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <!-- Umur -->
            <div>
                <label for="umur" class="block text-sm font-medium text-slate-700">Umur</label>
                <input type="number" id="umur" name="umur" value="<?= htmlspecialchars($user['umur'] ?? '') ?>" 
                       class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <!-- Kursus -->
            <div>
                <label for="kursus" class="block text-sm font-medium text-slate-700">Kursus</label>
                <input type="text" id="kursus" name="kursus" value="<?= htmlspecialchars($user['kursus'] ?? '') ?>" 
                       class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <!-- Bio -->
            <div>
                <label for="bio" class="block text-sm font-medium text-slate-700">Bio</label>
                <textarea id="bio" name="bio" rows="4" 
                          class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
            </div>

            <!-- Gambar -->
            <div>
                <label for="gambar" class="block text-sm font-medium text-slate-700">Gambar Profil</label>
                <input type="file" id="gambar" name="gambar" accept="image/*"
                       class="w-full mt-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <?php if (!empty($user['gambar'])): ?>
                    <img src="../uploads/<?= htmlspecialchars($user['gambar']) ?>" alt="Gambar Profil" 
                         class="w-24 h-24 object-cover rounded-full mt-3 border">
                <?php endif; ?>
            </div>

            <!-- Butang -->
            <div class="flex justify-between items-center">
                <a href="profile_guru.php" class="px-4 py-2 bg-gray-300 text-slate-800 rounded-lg hover:bg-gray-400 transition">
                    <i class="ph-arrow-left-fill"></i> Kembali
                </a>
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition">
                    <i class="ph-floppy-disk-fill"></i> Simpan
                </button>
            </div>
        </form>
    </div>
</body>
</html>
