<?php
session_start();
include("../include/connection.php");

// Pastikan login role guru
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data guru dari DB
$sql = "SELECT * FROM users WHERE id_user = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("Ralat: Maklumat profil tidak dijumpai.");
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Guru</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background: #e2e8f0; }
    </style>
</head>
<body class="flex justify-center p-4 md:p-8">

    <div class="w-full max-w-4xl space-y-4">

        <!-- Profile Card -->
        <div class="bg-white rounded-lg shadow-md relative">
            <!-- Cover -->
            <div class="w-full h-32 bg-sky-600 rounded-t-lg"></div>

            <div class="p-6">
                <!-- Gambar -->
                <div class="flex items-end -mt-16 mb-4">
                    <div class="w-28 h-28 md:w-36 md:h-36 rounded-full border-4 border-white shadow-lg overflow-hidden">
                        <img src="<?= !empty($user['gambar']) ? '../uploads/' . htmlspecialchars($user['gambar']) : 'https://placehold.co/300x300/60a5fa/ffffff?text=Guru' ?>" 
                             alt="Foto Profil" class="w-full h-full object-cover">
                    </div>
                </div>


                 <!-- Butang -->
                <div class="absolute top-4 right-4 flex space-x-2">
                    <a href="guru_dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-900 bg-white rounded-full border border-slate-900 hover:bg-slate-100 transition-colors duration-200">
                        <i class="ph-arrow-left-fill text-lg"></i>
                        <span>Kembali</span>
                    </a>
                    <a href="profile_edit.php" class="flex items-center space-x-2 px-4 py-2 text-sm font-semibold text-slate-900 bg-white rounded-full border border-slate-900 hover:bg-slate-100 transition-colors duration-200">
                        <i class="ph-pencil-fill text-lg"></i>
                        <span>Edit Profil</span>
                    </a>
                </div>

                <!-- Maklumat -->
                <div class="mt-4">
                    <h1 class="text-3xl font-bold text-slate-900"><?= htmlspecialchars($user['nama']) ?></h1>
                    <p class="text-md text-slate-600 mt-1"><?= htmlspecialchars($user['kursus'] ?? 'Kursus belum diisi') ?></p>
                    <div class="flex items-center space-x-2 text-slate-500 mt-2">
                        <i class="ph-calendar-blank-fill text-lg"></i>
                        <span><?= htmlspecialchars($user['umur'] ?? '-') ?> Umur</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bio -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-slate-800 mb-4">Bio</h2>
            <p class="text-slate-600 leading-relaxed">
                <?= !empty($user['bio']) ? nl2br(htmlspecialchars($user['bio'])) : 'Belum ada bio.' ?>
            </p>
        </div>

    </div>
</body>
</html>
