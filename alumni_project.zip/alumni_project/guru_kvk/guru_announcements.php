<?php
session_start();
include("../include/connection.php");

// ✅ Pastikan hanya guru boleh akses
if(!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: ../login.php");
    exit();
}

// Handle form submit
if(isset($_POST['submit'])) {
    $tajuk = $_POST['tajuk'];
    $kandungan = $_POST['kandungan'];
    $kategori = $_POST['kategori'];
    
    // Check if tarikh_tamat column exists
    $check_column = $conn->query("SHOW COLUMNS FROM announcements LIKE 'tarikh_tamat'");
    $has_tarikh_tamat_column = ($check_column && $check_column->num_rows > 0);
    
    $tarikh_tamat = ($has_tarikh_tamat_column && !empty($_POST['tarikh_tamat'])) ? $_POST['tarikh_tamat'] : NULL;

    // Handle file upload
    $gambar_path = NULL;
    if(isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $upload_dir = "../uploads/announcements/";
        if(!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
        $file_name = time().'_'.basename($_FILES['gambar']['name']);
        $target_file = $upload_dir.$file_name;
        if(move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)){
            $gambar_path = $file_name;
        }
    }

    // Insert with or without tarikh_tamat based on column existence
    if ($has_tarikh_tamat_column) {
        $stmt = $conn->prepare("INSERT INTO announcements (tajuk, kandungan, kategori, tarikh_tamat, gambar) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $tajuk, $kandungan, $kategori, $tarikh_tamat, $gambar_path);
    } else {
        $stmt = $conn->prepare("INSERT INTO announcements (tajuk, kandungan, kategori, gambar) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $tajuk, $kandungan, $kategori, $gambar_path);
    }
    
    $stmt->execute();
    $stmt->close();

    header("Location: guru_announcements.php");
    exit();
}

// Check if tarikh_tamat column exists and get announcements
$check_column = $conn->query("SHOW COLUMNS FROM announcements LIKE 'tarikh_tamat'");
$has_tarikh_tamat = ($check_column && $check_column->num_rows > 0);

// Get announcements (with or without tarikh_tamat column)
$result = $conn->query("SELECT * FROM announcements ORDER BY tarikh DESC");

// Kira statistik
$total_announcements = $result->num_rows;
$akademik_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM announcements WHERE kategori='Akademik'"))['total'];
$event_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM announcements WHERE kategori='Event'"))['total'];
$aktiviti_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM announcements WHERE kategori='Aktiviti'"))['total'];
?>

<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Guru Dashboard - Pengumuman</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    'primary': '#3B82F6',
                    'primary-dark': '#1D4ED8',
                    'accent': '#10B981',
                    'accent-dark': '#059669'
                }
            }
        }
    }
</script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    body { 
        font-family: 'Inter', sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .glass-effect {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    
    .card-hover {
        transition: all 0.3s ease;
    }
    
    .card-hover:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.3s ease;
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%);
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }
    
    .fade-in {
        animation: fadeIn 0.8s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .pulse-animation {
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    .navbar-glass {
        background: rgba(17, 24, 39, 0.95);
        backdrop-filter: blur(10px);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .stats-card {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
    }
    
    .stats-card:hover {
        transform: translateY(-8px) rotate(1deg);
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    }
    
    .form-focus:focus {
        transform: translateY(-1px);
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.25);
    }
</style>
</head>
<body class="min-h-screen">

<!-- Enhanced Navbar -->
<nav class="navbar-glass shadow-2xl sticky top-0 z-50">
    <div class="container mx-auto px-6 py-4">
        <div class="flex justify-between items-center">
            <div class="flex items-center space-x-4 mt-4 md:mt-0">
                <span class="text-gray-400 text-sm">Dibina dengan Aiman Company Sdn Bhd.</span>
            </div>
        </div>
    </div>
</footer>

<script>
ClassicEditor.create(document.querySelector('#editor'), {
    toolbar: [
        'heading', '|',
        'bold', 'italic', 'underline', '|',
        'bulletedList', 'numberedList', '|',
        'insertTable', 'link', 'blockQuote', '|',
        'undo', 'redo'
    ],
    heading: {
        options: [
            { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
        ]
    }
}).catch(error => {
    console.error(error);
});

// File upload preview
document.getElementById('file-upload').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.createElement('img');
            preview.src = e.target.result;
            preview.className = 'max-w-full h-32 object-cover rounded-lg mt-2';
            
            const label = document.querySelector('label[for="file-upload"]');
            const existing = label.querySelector('img');
            if (existing) {
                existing.remove();
            }
            label.appendChild(preview);
        };
        reader.readAsDataURL(file);
    }
});

// Smooth scrolling functions
function scrollToForm() {
    document.getElementById('create-form').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
}

function scrollToList() {
    document.getElementById('announcements-list').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
}

// Add interactive animations
document.addEventListener('DOMContentLoaded', function() {
    // Animate numbers
    const numbers = document.querySelectorAll('.pulse-animation');
    numbers.forEach(number => {
        const target = parseInt(number.textContent);
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            number.textContent = Math.floor(current);
        }, 30);
    });
    
    // Add hover effects to cards
    const cards = document.querySelectorAll('.card-hover');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Search functionality dengan null check
    const searchInput = document.querySelector('input[placeholder="Cari pengumuman..."]');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const announcementContainer = document.querySelector('#announcements-list .space-y-6');
            if (announcementContainer) {
                const announcements = announcementContainer.children;
                
                Array.from(announcements).forEach(announcement => {
                    const titleElement = announcement.querySelector('h3');
                    const contentElement = announcement.querySelector('.text-gray-600');
                    
                    if (titleElement && contentElement) {
                        const title = titleElement.textContent.toLowerCase();
                        const content = contentElement.textContent.toLowerCase();
                        
                        if (title.includes(searchTerm) || content.includes(searchTerm)) {
                            announcement.style.display = 'block';
                        } else {
                            announcement.style.display = 'none';
                        }
                    }
                });
            }
        });
    }
    
    // Category filter dengan null check
    const categorySelect = document.querySelector('select');
    if (categorySelect && categorySelect.options.length > 1) {
        categorySelect.addEventListener('change', function() {
            const selectedCategory = this.value;
            const announcementContainer = document.querySelector('#announcements-list .space-y-6');
            if (announcementContainer) {
                const announcements = announcementContainer.children;
                
                Array.from(announcements).forEach(announcement => {
                    const categoryElement = announcement.querySelector('.bg-gray-100');
                    if (categoryElement) {
                        if (selectedCategory === 'Semua Kategori') {
                            announcement.style.display = 'block';
                        } else {
                            const category = categoryElement.textContent.trim();
                            if (category === selectedCategory) {
                                announcement.style.display = 'block';
                            } else {
                                announcement.style.display = 'none';
                            }
                        }
                    }
                });
            }
        });
    }
});
</script>

</body>
</html> items-center space-x-4">
                <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-bullhorn text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="text-white text-2xl font-bold">Pusat Pengumuman</h1>
                    <p class="text-gray-300 text-sm">Sistem Pengurusan Pengumuman</p>
                </div>
            </div>
            
            <div class="hidden md:flex items-center space-x-6">
                <a class="text-gray-300 hover:text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 hover:bg-white hover:bg-opacity-10" href="guru_dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
                <a class="text-white hover:text-blue-300 px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 bg-white bg-opacity-10" href="guru_announcements.php">
                    <i class="fas fa-bullhorn"></i>
                    <span>Pengumuman</span>
                </a>
                <a class="text-gray-300 hover:text-white px-4 py-2 rounded-lg font-medium transition-all duration-300 flex items-center space-x-2 hover:bg-white hover:bg-opacity-10" href="guru_students.php">
                    <i class="fas fa-users"></i>
                    <span>Pelajar</span>
                </a>
            </div>
            
            <div class="flex items-center space-x-4">
                <div class="text-white text-right hidden sm:block">
                    <p class="text-sm font-medium">Selamat Datang</p>
                    <p class="text-xs text-gray-300">Guru</p>
                </div>
                <a href="guru_dashboard.php" 
                   class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded-xl transition-all duration-300 flex items-center space-x-2 shadow-lg hover:shadow-xl">
                   <i class="fas fa-arrow-left"></i>
                   <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<div class="py-16 px-6 fade-in">
    <div class="max-w-6xl mx-auto text-center">
        <div class="mb-8">
            <h1 class="text-5xl sm:text-6xl font-bold text-white mb-4">
                <i class="fas fa-bullhorn mr-4"></i>
                Dashboard Pengumuman
            </h1>
            <p class="text-xl text-white opacity-90 max-w-3xl mx-auto">
                Cipta dan urus pengumuman sekolah dengan dashboard yang komprehensif dan mudah digunakan
            </p>
        </div>
        
        <!-- Quick Actions -->
        <div class="flex flex-wrap justify-center gap-4 mb-12">
            <button onclick="scrollToForm()" class="btn-gradient text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl flex items-center space-x-2">
                <i class="fas fa-plus"></i>
                <span>Cipta Pengumuman</span>
            </button>
            <button onclick="scrollToList()" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                <i class="fas fa-list"></i>
                <span>Lihat Senarai</span>
            </button>
            <a href="reports.php" class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-2">
                <i class="fas fa-chart-bar"></i>
                <span>Laporan</span>
            </a>
        </div>
    </div>
</div>

<!-- Main Content -->
<main class="max-w-7xl mx-auto px-6 pb-16">
    
    <!-- Stats Cards -->
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
        <!-- Total Announcements -->
        <div class="stats-card rounded-2xl p-8 card-hover fade-in">
            <div class="flex items-center justify-between mb-4">
                <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-bullhorn text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $total_announcements; ?></p>
                    <p class="text-gray-600 font-medium">Jumlah Pengumuman</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full" style="width: 100%"></div>
            </div>
        </div>
        
        <!-- Akademik -->
        <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.1s">
            <div class="flex items-center justify-between mb-4">
                <div class="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-graduation-cap text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $akademik_count; ?></p>
                    <p class="text-gray-600 font-medium">Akademik</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="bg-gradient-to-r from-green-500 to-green-600 h-2 rounded-full" 
                     style="width: <?php echo $total_announcements > 0 ? ($akademik_count / $total_announcements) * 100 : 0; ?>%"></div>
            </div>
        </div>
        
        <!-- Event -->
        <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.2s">
            <div class="flex items-center justify-between mb-4">
                <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-calendar-alt text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $event_count; ?></p>
                    <p class="text-gray-600 font-medium">Event</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full" 
                     style="width: <?php echo $total_announcements > 0 ? ($event_count / $total_announcements) * 100 : 0; ?>%"></div>
            </div>
        </div>
        
        <!-- Aktiviti -->
        <div class="stats-card rounded-2xl p-8 card-hover fade-in" style="animation-delay: 0.3s">
            <div class="flex items-center justify-between mb-4">
                <div class="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-running text-white text-2xl"></i>
                </div>
                <div class="text-right">
                    <p class="text-4xl font-bold text-gray-800 pulse-animation"><?php echo $aktiviti_count; ?></p>
                    <p class="text-gray-600 font-medium">Aktiviti</p>
                </div>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
                <div class="bg-gradient-to-r from-orange-500 to-orange-600 h-2 rounded-full" 
                     style="width: <?php echo $total_announcements > 0 ? ($aktiviti_count / $total_announcements) * 100 : 0; ?>%"></div>
            </div>
        </div>
    </section>

    <!-- Create Form -->
    <section id="create-form" class="mb-16">
        <div class="glass-effect rounded-2xl shadow-2xl fade-in overflow-hidden" style="animation-delay: 0.4s">
            <div class="bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-6">
                <h2 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-plus-circle mr-3"></i>
                    Cipta Pengumuman Baru
                </h2>
            </div>
            
            <form method="post" enctype="multipart/form-data" class="p-8">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    
                    <!-- Left Column -->
                    <div class="space-y-6">
                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-3">
                                <i class="fas fa-heading mr-2 text-gray-400"></i>
                                Tajuk Pengumuman
                            </label>
                            <input type="text" name="tajuk" required 
                                   class="w-full border border-gray-300 rounded-xl px-4 py-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all form-focus bg-white bg-opacity-70"
                                   placeholder="Masukkan tajuk pengumuman yang menarik...">
                        </div>

                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-3">
                                <i class="fas fa-tags mr-2 text-gray-400"></i>
                                Kategori
                            </label>
                            <select name="kategori" class="w-full border border-gray-300 rounded-xl px-4 py-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white bg-opacity-70">
                                <option value="Akademik">📚 Akademik</option>
                                <option value="Event">🎉 Event</option>
                                <option value="Aktiviti">🏃 Aktiviti</option>
                                <option value="Lain-lain">📝 Lain-lain</option>
                            </select>
                        </div>

                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-3">
                                <i class="fas fa-clock mr-2 text-gray-400"></i>
                                Tarikh Tamat (Pilihan)
                            </label>
                            <?php if ($has_tarikh_tamat): ?>
                                <input type="datetime-local" name="tarikh_tamat" 
                                       class="w-full border border-gray-300 rounded-xl px-4 py-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all bg-white bg-opacity-70">
                            <?php else: ?>
                                <div class="w-full border border-gray-300 rounded-xl px-4 py-4 bg-gray-100 bg-opacity-70 text-gray-500">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    Feature ini memerlukan column 'tarikh_tamat' dalam database
                                </div>
                            <?php endif; ?>
                        </div>

                        <div>
                            <label class="flex items-center text-sm font-semibold text-gray-700 mb-3">
                                <i class="fas fa-image mr-2 text-gray-400"></i>
                                Gambar (Pilihan)
                            </label>
                            <div class="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors bg-white bg-opacity-50">
                                <input type="file" name="gambar" accept="image/*" class="hidden" id="file-upload">
                                <label for="file-upload" class="cursor-pointer">
                                    <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-3"></i>
                                    <p class="text-gray-500 font-medium">Klik untuk muat naik gambar</p>
                                    <p class="text-sm text-gray-400">PNG, JPG hingga 10MB</p>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column -->
                    <div>
                        <label class="flex items-center text-sm font-semibold text-gray-700 mb-3">
                            <i class="fas fa-edit mr-2 text-gray-400"></i>
                            Kandungan Pengumuman
                        </label>
                        <div class="border border-gray-300 rounded-xl overflow-hidden bg-white bg-opacity-70">
                            <textarea name="kandungan" id="editor" class="min-h-[400px]"></textarea>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end mt-8 pt-6 border-t border-gray-200">
                    <button type="submit" name="submit" 
                            class="btn-gradient text-white px-8 py-4 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center space-x-3">
                        <i class="fas fa-paper-plane"></i>
                        <span>Terbitkan Pengumuman</span>
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- Announcements List -->
    <section id="announcements-list">
        <div class="glass-effect rounded-2xl shadow-2xl fade-in" style="animation-delay: 0.5s">
            <div class="bg-gradient-to-r from-green-500 to-blue-600 px-8 py-6 flex items-center justify-between">
                <h2 class="text-2xl font-bold text-white flex items-center">
                    <i class="fas fa-list mr-3"></i>
                    Senarai Pengumuman
                </h2>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center bg-white bg-opacity-20 rounded-xl px-4 py-3">
                        <i class="fas fa-search text-white mr-2"></i>
                        <input type="text" placeholder="Cari pengumuman..." class="bg-transparent text-white placeholder-white placeholder-opacity-70 border-none outline-none">
                    </div>
                    <select class="bg-white bg-opacity-20 text-white rounded-xl px-4 py-3 border-none outline-none">
                        <option>Semua Kategori</option>
                        <option>Akademik</option>
                        <option>Event</option>
                        <option>Aktiviti</option>
                    </select>
                </div>
            </div>
            
            <div class="p-8">
                <?php if($result->num_rows > 0): ?>
                    <div class="space-y-6">
                        <?php while($row = $result->fetch_assoc()): ?>
                        <div class="bg-white bg-opacity-70 border border-gray-200 rounded-xl p-8 hover:shadow-lg transition-all duration-300 hover:border-blue-300 card-hover">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center mb-4">
                                        <?php 
                                        $kategori_icons = [
                                            'Akademik' => 'fas fa-graduation-cap text-blue-500',
                                            'Event' => 'fas fa-calendar-alt text-green-500', 
                                            'Aktiviti' => 'fas fa-running text-orange-500',
                                            'Lain-lain' => 'fas fa-info-circle text-gray-500'
                                        ];
                                        $icon = $kategori_icons[$row['kategori']] ?? 'fas fa-info-circle text-gray-500';
                                        ?>
                                        <i class="<?php echo $icon; ?> mr-3 text-lg"></i>
                                        <span class="text-xs font-semibold bg-gray-100 text-gray-600 px-3 py-2 rounded-full">
                                            <?php echo $row['kategori']; ?>
                                        </span>
                                        <span class="ml-4 text-sm text-gray-500 flex items-center">
                                            <i class="fas fa-clock mr-2"></i>
                                            <?php echo date('d/m/Y H:i', strtotime($row['tarikh'])); ?>
                                        </span>
                                    </div>
                                    
                                    <h3 class="font-bold text-xl text-gray-800 mb-4 hover:text-blue-600 transition-colors">
                                        <?php echo htmlspecialchars($row['tajuk']); ?>
                                    </h3>
                                    
                                    <div class="text-gray-600 mb-4 leading-relaxed">
                                        <?php echo substr(strip_tags($row['kandungan']), 0, 200); ?>
                                        <?php if(strlen(strip_tags($row['kandungan'])) > 200): ?>
                                            <span class="text-blue-500 cursor-pointer font-medium">... Baca lagi</span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if($has_tarikh_tamat && isset($row['tarikh_tamat']) && !empty($row['tarikh_tamat'])): ?>
                                        <div class="flex items-center text-sm text-orange-600 mb-4">
                                            <i class="fas fa-hourglass-half mr-2"></i>
                                            Tamat: <?php echo date('d/m/Y H:i', strtotime($row['tarikh_tamat'])); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if($row['gambar']): ?>
                                    <div class="ml-8 flex-shrink-0">
                                        <img src="../uploads/announcements/<?php echo $row['gambar']; ?>" 
                                             class="w-32 h-32 object-cover rounded-xl shadow-lg">
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="flex items-center justify-between pt-6 border-t border-gray-200">
                                <div class="flex items-center space-x-6 text-sm text-gray-500">
                                    <span class="flex items-center">
                                        <i class="fas fa-eye mr-2"></i>
                                        125 views
                                    </span>
                                    <span class="flex items-center">
                                        <i class="fas fa-heart mr-2"></i>
                                        12 likes
                                    </span>
                                    <span class="flex items-center">
                                        <i class="fas fa-comment mr-2"></i>
                                        5 comments
                                    </span>
                                </div>
                                
                                <div class="flex items-center space-x-3">
                                    <button class="px-4 py-2 text-sm bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors font-medium">
                                        <i class="fas fa-edit mr-2"></i>Edit
                                    </button>
                                    <button class="px-4 py-2 text-sm bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors font-medium">
                                        <i class="fas fa-trash mr-2"></i>Padam
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
                        <p class="text-sm text-gray-500">
                            Menunjukkan 1-<?php echo $result->num_rows; ?> daripada <?php echo $result->num_rows; ?> pengumuman
                        </p>
                        <div class="flex items-center space-x-2">
                            <button class="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                Previous
                            </button>
                            <button class="px-4 py-2 text-sm bg-blue-500 text-white rounded-lg">1</button>
                            <button class="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                Next
                            </button>
                        </div>
                    </div>
                    
                <?php else: ?>
                    <div class="text-center py-16">
                        <i class="fas fa-bullhorn text-6xl text-gray-300 mb-6"></i>
                        <h3 class="text-2xl font-semibold text-gray-500 mb-3">Tiada Pengumuman</h3>
                        <p class="text-gray-400">Belum ada pengumuman yang diterbitkan. Cipta pengumuman pertama anda!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

</main>

<!-- Enhanced Footer -->
<footer class="navbar-glass mt-16 py-8">
    <div class="max-w-6xl mx-auto px-6 text-center">
        <div class="flex flex-col md:flex-row justify-between items-center">
            <div class="flex items-center space-x-3 mb-4 md:mb-0">
                <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <i class="fas fa-graduation-cap text-white"></i>
                </div>
                <span class="text-white font-semibold">Sistem Pengumuman</span>
            </div>
            <p class="text-gray-300 text-sm">
                &copy; 2025 Projek Alumni. Hak cipta terpelihara.
            </p>
            <div class="flex