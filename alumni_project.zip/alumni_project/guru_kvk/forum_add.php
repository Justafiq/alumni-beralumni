<?php
session_start();
include("../include/connection.php");

// ====== CHECK LOGIN ======
if (!isset($_SESSION['role']) || $_SESSION['role'] !== "guru") {
    header("Location: ../login.php");
    exit();
}

$msg = "";

// ====== HANDLE FORM SUBMIT ======
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $tajuk = mysqli_real_escape_string($conn, $_POST['tajuk']);
    $kandungan = mysqli_real_escape_string($conn, $_POST['kandungan']);
    $user_id = $_SESSION['user_id']; // ambil dari session

    // Upload gambar jika ada
    $gambar = NULL;
    if (!empty($_FILES['gambar']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir);

        $fileName = time() . "_" . basename($_FILES['gambar']['name']);
        $targetFile = $targetDir . $fileName;

        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $targetFile)) {
            $gambar = "uploads/" . $fileName; // simpan relative path
        } else {
            $msg = "⚠️ Gagal upload gambar.";
        }
    }

    // Insert ke DB (guna user_id)
    $sql = "INSERT INTO forum (tajuk, kandungan, gambar, user_id) 
            VALUES ('$tajuk', '$kandungan', " . ($gambar ? "'$gambar'" : "NULL") . ", '$user_id')";
    if (mysqli_query($conn, $sql)) {
        $msg = "✅ Forum berjaya dipost!";
    } else {
        $msg = "❌ Ralat: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Tambah Forum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">📝 Post Forum Baru</h2>
    <?php if (!empty($msg)): ?>
        <div class="alert alert-info"><?= $msg ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Tajuk</label>
            <input type="text" name="tajuk" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Kandungan</label>
            <textarea name="kandungan" rows="5" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Gambar (Optional)</label>
            <input type="file" name="gambar" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Post</button>
        <a href="guru_dashboard.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
